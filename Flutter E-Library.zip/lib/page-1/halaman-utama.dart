import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // halamanutama17W (9:109)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // mainRaY (18:79)
              left: 0*fem,
              top: 64*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(10*fem, 10*fem, 10*fem, 10*fem),
                width: 434*fem,
                height: 868*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Align(
                  // perpus12KS (19:78)
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    width: 414*fem,
                    height: 812*fem,
                    child: Image.asset(
                      'assets/page-1/images/perpus-1-8wJ.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // jzY (12:35)
              left: 0*fem,
              top: 876*fem,
              child: Container(
                width: 430*fem,
                height: 56*fem,
                child: Container(
                  // autogroupqifa5Yc (R1Xyx1GwFA8B7H1z6tQifa)
                  padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    color: Color(0xfff0f0f0),
                    borderRadius: BorderRadius.only (
                      topLeft: Radius.circular(8*fem),
                      topRight: Radius.circular(8*fem),
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // bnitemkPr (I12:37;371:4252)
                        padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                        width: 135*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconggp (I12:37;371:4252;371:4235)
                              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-PTW.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                            Text(
                              // labelQ72 (I12:37;371:4252;371:4246)
                              'Dashboard',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3333333333*ffem/fem,
                                color: Color(0xff858585),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 8*fem,
                      ),
                      Container(
                        // bnitemsWQ (I12:38;371:4765)
                        padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                        width: 136*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconPje (I12:38;371:4765;371:4235)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                            Text(
                              // labelvUg (I12:38;371:4765;371:4246)
                              'Bookmarked',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3333333333*ffem/fem,
                                color: Color(0xff263238),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 8*fem,
                      ),
                      Container(
                        // bnitemdP6 (I12:39;371:5376)
                        padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                        width: 135*fem,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconwua (I12:39;371:5376;371:4235)
                              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-hGL.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                            Text(
                              // label3hi (I12:39;371:5376;371:4246)
                              'Wishlist',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3333333333*ffem/fem,
                                color: Color(0xff263238),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // labelBov (22:319)
              left: 118*fem,
              top: 252*fem,
              child: Align(
                child: SizedBox(
                  width: 228*fem,
                  height: 224*fem,
                  child: Text(
                    '"When in doubt, go to the library, the library holds the energy that fuels the imagination."',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 36*ffem,
                      fontWeight: FontWeight.w600,
                      height: 0.7777777778*ffem/fem,
                      letterSpacing: 0.150000006*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroups6mnTmS (R1Xy22psMoTpdkUZtJS6MN)
              left: 0*fem,
              top: 476*fem,
              child: Container(
                width: 430*fem,
                height: 400*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // BhS (19:89)
                      left: 143*fem,
                      top: 325*fem,
                      child: Container(
                        width: 132*fem,
                        height: 44*fem,
                      ),
                    ),
                    Positioned(
                      // containericonright8cg (19:90)
                      left: 126*fem,
                      top: 329*fem,
                      child: Container(
                        width: 179*fem,
                        height: 44*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(8*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x19000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x28000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 1*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // labelaDn (I19:90;108:1393)
                              left: 66.5*fem,
                              top: 8.0000305176*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 46*fem,
                                    height: 28*fem,
                                    child: Text(
                                      'Next',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.4*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff263238),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // iconrightezL (I19:90;108:1394)
                              left: 99*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 80*fem,
                                  height: 44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-right.png',
                                    width: 80*fem,
                                    height: 44*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarASt (34:772)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeExY (I34:772;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsXwe (I34:772;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-UVW.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}