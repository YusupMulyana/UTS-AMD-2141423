import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax6DLL (39:320)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // frame7KPN (39:322)
              left: 6*fem,
              top: 109*fem,
              child: Container(
                width: 415*fem,
                height: 767*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0x93ff3d00),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // backgroundQQp (39:323)
                      left: 10*fem,
                      top: 2.6154785156*fem,
                      child: Align(
                        child: SizedBox(
                          width: 394*fem,
                          height: 764.38*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                              border: Border.all(color: Color(0x93ff3d00)),
                              color: Color(0xaa565656),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // backgroundVBN (39:549)
                      left: 26*fem,
                      top: 109*fem,
                      child: Align(
                        child: SizedBox(
                          width: 360*fem,
                          height: 454*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffffffff)),
                              color: Color(0xff9f9898),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group11PXe (39:547)
                      left: 26*fem,
                      top: 118*fem,
                      child: Container(
                        width: 360*fem,
                        height: 439*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // backgroundW6U (39:537)
                              left: 118*fem,
                              top: 7.6589355469*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 135*fem,
                                  height: 182.63*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(20*fem),
                                      border: Border.all(color: Color(0xffffffff)),
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // background1Z2 (39:538)
                              left: 112*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 135*fem,
                                  height: 182.63*fem,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20*fem),
                                    child: Image.asset(
                                      'assets/page-1/images/background-LXz.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vR6 (39:448)
                              left: 0*fem,
                              top: 201*fem,
                              child: Container(
                                width: 360*fem,
                                height: 238*fem,
                                child: Container(
                                  // textonlytestimonialFyA (39:449)
                                  width: 990*fem,
                                  height: 244*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // backgroundaEk (I39:449;391:2812)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 360*fem,
                                            height: 244*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(4*fem),
                                                color: Color(0xffffffff),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Color(0x19000000),
                                                    offset: Offset(0*fem, 1*fem),
                                                    blurRadius: 4*fem,
                                                  ),
                                                  BoxShadow(
                                                    color: Color(0x1e000000),
                                                    offset: Offset(0*fem, 2*fem),
                                                    blurRadius: 2*fem,
                                                  ),
                                                  BoxShadow(
                                                    color: Color(0x28000000),
                                                    offset: Offset(0*fem, 1*fem),
                                                    blurRadius: 1*fem,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // img1L4 (I39:449;391:2805;255:4183;0:401)
                                        left: 16*fem,
                                        top: 16*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 40*fem,
                                            height: 40*fem,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(9999*fem),
                                              child: Image.asset(
                                                'assets/page-1/images/img-c2C.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // thumbdownJpx (I39:449;391:2769)
                                        left: 264*fem,
                                        top: 16*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 40*fem,
                                            height: 40*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/thumb-down.png',
                                              width: 40*fem,
                                              height: 40*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // thumbupCvL (39:579)
                                        left: 314*fem,
                                        top: 87.4694824219*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 27*fem,
                                            height: 27*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/thumb-up.png',
                                              width: 27*fem,
                                              height: 27*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // ratingJyN (39:557)
                                        left: 8.5*fem,
                                        top: 96.9694824219*fem,
                                        child: Container(
                                          width: 147.5*fem,
                                          height: 24*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // autogroupzj4pE6L (R1YXmbFj768C1CYHoMzJ4p)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.5*fem, 0*fem),
                                                width: 82*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/auto-group-zj4p.png',
                                                  width: 82*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                              Text(
                                                // value8hW (I39:557;255:4627)
                                                '3 days ago',
                                                style: SafeGoogleFont (
                                                  'Inter',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0xff263238),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // body4LG (39:556)
                                        left: 13*fem,
                                        top: 125.4694824219*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 327*fem,
                                            height: 80*fem,
                                            child: Text(
                                              'Text labels need to be distinct from other elements. If the text label isn’t capitalized, it should use a different color, style, or layout from other text.',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 0.07*fem,
                                                color: Color(0xff263238),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // thumbdownjxC (39:552)
                                        left: 276*fem,
                                        top: 94.4694824219*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 28*fem,
                                            height: 30*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/thumb-down-h92.png',
                                              width: 28*fem,
                                              height: 30*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // title3hz (39:550)
                                        left: 64*fem,
                                        top: 11.4694824219*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 266*fem,
                                            height: 48*fem,
                                            child: Text(
                                              'SISTEM INFORMASI ANALISA DAN PERANCANGAN',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                letterSpacing: 0.16*fem,
                                                color: Color(0xff263238),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // counterKQc (39:551)
                                        left: 64*fem,
                                        top: 63.4694824219*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 84*fem,
                                            height: 20*fem,
                                            child: Text(
                                              '5K READING',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 0.07*fem,
                                                color: Color(0xff263238),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // importNNt (41:619)
                                        left: 314*fem,
                                        top: 214.4694824219*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/import.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // containericonlefte5W (39:539)
              left: 6*fem,
              top: 65*fem,
              child: Container(
                width: 415*fem,
                height: 44*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x19000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 4*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 2*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x28000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 1*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // iconleftg2C (I39:539;108:1389)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 80*fem,
                          height: 44*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-left-wzQ.png',
                            width: 80*fem,
                            height: 44*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // labelZrg (39:546)
                      left: 66.5*fem,
                      top: 7.5714111328*fem,
                      child: Center(
                        child: Align(
                          child: SizedBox(
                            width: 338*fem,
                            height: 28*fem,
                            child: Text(
                              'Buku Sistem Informasi Analisan ....',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.4*ffem/fem,
                                letterSpacing: 0.150000006*fem,
                                color: Color(0xff263238),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // 3Wx (39:346)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupxsn8MnY (R1YY8AVnCS5oZB2Npkxsn8)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogrouprovgskt (R1YYEQpNUrE148vM4Zrovg)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination1Zdi (I39:346;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                            ),
                            child: Container(
                              // bnitemgyE (I39:346;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconRA8 (I39:346;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-3rY.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // label8qE (I39:346;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupfy7ag64 (R1YYMExKkUfyhzS6mBfY7a)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemQGx (I39:346;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconujW (I39:346;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-AF2.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labeleh6 (I39:346;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitemCCp (I39:346;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconvec (I39:346;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-9xk.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelpzt (I39:346;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarZBn (39:347)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timerRn (I39:347;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsABa (I39:347;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-9Qk.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}