import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax16oj6 (71:1956)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // main7Dz (71:2138)
              left: 0*fem,
              top: 64*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(10*fem, 10*fem, 10*fem, 10*fem),
                width: 434*fem,
                height: 868*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Align(
                  // perpus1MPE (I71:2138;19:78)
                  alignment: Alignment.topCenter,
                  child: SizedBox(
                    width: 414*fem,
                    height: 812*fem,
                    child: Image.asset(
                      'assets/page-1/images/perpus-1-d2Q.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // gRW (71:2078)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupnx2yc4G (R1Y8hvMHhRiwCqLXctnX2Y)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogroupi3wgw6Y (R1Y8pv9dXyQH3WjwAbi3Wg)
                      padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // bnitemciU (I71:2078;12:37;371:4252)
                            padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                            width: 135*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // iconY6L (I71:2078;12:37;371:4252;371:4235)
                                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-skC.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // label3Yt (I71:2078;12:37;371:4252;371:4246)
                                  'Dashboard',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xff858585),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // bnitemxQx (I71:2078;12:38;371:4765)
                            padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                            width: 136*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // icon5kU (I71:2078;12:38;371:4765;371:4235)
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-9eY.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // label18L (I71:2078;12:38;371:4765;371:4246)
                                  'Bookmarked',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xff263238),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // bnitemiHe (I71:2078;12:39;371:5376)
                            padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                            width: 135*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // icondQc (I71:2078;12:39;371:5376;371:4235)
                                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/icon-HCt.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // label9Nx (I71:2078;12:39;371:5376;371:4246)
                                  'Wishlist',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.3333333333*ffem/fem,
                                    color: Color(0xff263238),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group6UAL (71:2111)
              left: 49*fem,
              top: 322*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(10.71*fem, 22.56*fem, 11*fem, 31.99*fem),
                width: 332*fem,
                height: 316*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0xaa565656),
                  borderRadius: BorderRadius.circular(20*fem),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupgnm67j6 (R1Y9ZeRS7P1URJfokjGnm6)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.29*fem, 25.28*fem),
                      width: double.infinity,
                      height: 47.16*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(20*fem),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Please Read, thanks.',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 23*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2173913043*ffem/fem,
                              letterSpacing: 0.150000006*fem,
                              color: Color(0xb5000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // group7jkU (71:2117)
                      margin: EdgeInsets.fromLTRB(0.29*fem, 0*fem, 0*fem, 29*fem),
                      padding: EdgeInsets.fromLTRB(17*fem, 19*fem, 17*fem, 23.5*fem),
                      width: double.infinity,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(20*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            // labelokL (71:2136)
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9.5*fem),
                              width: double.infinity,
                              child: Text(
                                'Hallo,',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 23*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2173913043*ffem/fem,
                                  letterSpacing: 0.150000006*fem,
                                  color: Color(0xb5000000),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupdnecW8x (R1Y9tdsnp1H7hSCCEndnec)
                            margin: EdgeInsets.fromLTRB(12.38*fem, 0*fem, 46*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // usercircledzG (71:2127)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.38*fem, 0*fem),
                                  width: 38.25*fem,
                                  height: 39*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/user-circle.png',
                                    width: 38.25*fem,
                                    height: 39*fem,
                                  ),
                                ),
                                Center(
                                  // labelxWk (71:2137)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.5*fem),
                                    child: Text(
                                      'Yusup Mulyana',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 23*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2173913043*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xb5000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupckc8GnL (R1Y9doyAJKmc5ww7uwCkC8)
                      margin: EdgeInsets.fromLTRB(44.29*fem, 0*fem, 43*fem, 0*fem),
                      width: double.infinity,
                      height: 41.01*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // minibuttonziL (71:2142)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 61*fem, 0*fem),
                            width: 81*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(5*fem),
                            ),
                            child: Center(
                              child: Text(
                                'OK',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Kanit',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.495*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // minibuttonGQx (71:2126)
                            width: 81*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(5*fem),
                            ),
                            child: Center(
                              child: Text(
                                'Cancel',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Kanit',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.495*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarTVS (71:2007)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timejC4 (I71:2007;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsScG (I71:2007;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-3Yt.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}