import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax14xYp (71:1358)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgrounds9z (71:1629)
              left: 7*fem,
              top: 115*fem,
              child: Align(
                child: SizedBox(
                  width: 415*fem,
                  height: 769*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x19000000),
                          offset: Offset(0*fem, 1*fem),
                          blurRadius: 4*fem,
                        ),
                        BoxShadow(
                          color: Color(0x1e000000),
                          offset: Offset(0*fem, 2*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x28000000),
                          offset: Offset(0*fem, 1*fem),
                          blurRadius: 1*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group26VBN (75:1527)
              left: 25*fem,
              top: 152*fem,
              child: Container(
                width: 378*fem,
                height: 381*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // 19i (71:1804)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                      width: 377*fem,
                      height: 44*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.circular(8*fem),
                      ),
                      child: Container(
                        // defaultsingleiconizedKgC (I71:1804;71:1528)
                        width: double.infinity,
                        height: double.infinity,
                        child: Container(
                          // autogroupvczwGrL (R1YPnzDD2TCngETEVMVcZW)
                          padding: EdgeInsets.fromLTRB(16*fem, 2*fem, 10*fem, 1*fem),
                          width: double.infinity,
                          height: 43*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupo8gxBiQ (R1YPwEUU7t7NR732tDo8Gx)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                width: 40*fem,
                                height: double.infinity,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // iconleftiiL (I71:1804;71:1531)
                                      left: 8*fem,
                                      top: 8*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-left-Wpp.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // imgQbA (I71:1804;71:1536)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 40*fem,
                                          height: 40*fem,
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(2*fem),
                                            child: Image.asset(
                                              'assets/page-1/images/img-PTW.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // labelKCL (I71:1804;71:1537)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 159*fem, 0*fem),
                                child: Text(
                                  'Hapus Data',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.16*fem,
                                    color: Color(0xff263238),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupttq2CG8 (R1YQ39UHGTnqYR9hRrTTq2)
                                margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(17*fem, 0*fem, 0*fem, 0*fem),
                                height: double.infinity,
                                child: Align(
                                  // iconrightKLk (71:1821)
                                  alignment: Alignment.centerRight,
                                  child: SizedBox(
                                    width: 29*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-right-Wz4.png',
                                      width: 29*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // 31r (71:1787)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 31.84*fem),
                      width: 377*fem,
                      height: 44*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.circular(8*fem),
                      ),
                      child: Container(
                        // defaultsingleiconizedYjJ (I71:1787;71:1528)
                        width: double.infinity,
                        height: double.infinity,
                        child: Container(
                          // autogroupatua6Vv (R1YP4bGBat4Kg6JfbQATua)
                          padding: EdgeInsets.fromLTRB(16*fem, 2*fem, 16*fem, 1*fem),
                          width: double.infinity,
                          height: 43*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupqnwrcjA (R1YPBLZwa3tcjXsbNUQnwr)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                width: 40*fem,
                                height: double.infinity,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // iconleftYMv (I71:1787;71:1531)
                                      left: 8*fem,
                                      top: 8*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icon-left-fXn.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // imgrtQ (I71:1787;71:1536)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 40*fem,
                                          height: 40*fem,
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(2*fem),
                                            child: Image.asset(
                                              'assets/page-1/images/img-Xxc.png',
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // labelPNY (I71:1787;71:1537)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 134*fem, 0*fem),
                                child: Text(
                                  'Latar Belakang',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    letterSpacing: 0.16*fem,
                                    color: Color(0xff263238),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupwjmjhPE (R1YPHAjZSAxQGS3RzZWjMJ)
                                margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                                padding: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 2*fem),
                                height: double.infinity,
                                child: Center(
                                  // switchcWC (I71:1787;71:1543)
                                  child: SizedBox(
                                    width: 40*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/switch-qWY.png',
                                      width: 40*fem,
                                      height: 20*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // group24LBJ (71:1630)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                      width: 377*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(8*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // T12 (71:1527)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30.8*fem),
                            width: double.infinity,
                            height: 43.12*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // defaultsingleiconizedyzx (71:1528)
                              width: double.infinity,
                              height: 44*fem,
                              child: Container(
                                // autogroup1je4jz8 (R1YNMrw3pVDWYD4dAL1JE4)
                                padding: EdgeInsets.fromLTRB(16*fem, 2*fem, 16*fem, 1*fem),
                                width: double.infinity,
                                height: 43*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroup8py6ror (R1YNUSaREjpSQpju6K8py6)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                      width: 40*fem,
                                      height: double.infinity,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // iconleftmfv (71:1531)
                                            left: 8*fem,
                                            top: 8*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/icon-left-Vyi.png',
                                                  width: 24*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // imgfmJ (71:1536)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 40*fem,
                                                height: 40*fem,
                                                child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(2*fem),
                                                  child: Image.asset(
                                                    'assets/page-1/images/img-3EQ.png',
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // labeladN (71:1537)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 137*fem, 0*fem),
                                      child: Text(
                                        'Autodownload',
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          letterSpacing: 0.16*fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // autogroupumy2u9r (R1YNac4pEhLxKNh3QaUMy2)
                                      margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                                      padding: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 2*fem),
                                      height: double.infinity,
                                      child: Center(
                                        // switchEC8 (71:1543)
                                        child: SizedBox(
                                          width: 40*fem,
                                          height: 20*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/switch-Uoi.png',
                                            width: 40*fem,
                                            height: 20*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // N3S (71:1525)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30.8*fem),
                            width: double.infinity,
                            height: 55.44*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // defaultdoubletGg (71:1526)
                              width: double.infinity,
                              height: 56*fem,
                              child: Container(
                                // autogroupvucq3QU (R1YMkDHnN5uLbWUz3SvUcQ)
                                padding: EdgeInsets.fromLTRB(16*fem, 8*fem, 16*fem, 4*fem),
                                width: double.infinity,
                                height: 55*fem,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupwd4cm5a (R1YMrdGmDRGuHJGc8LwD4C)
                                      margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 108*fem, 0*fem),
                                      width: 197*fem,
                                      height: 35*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // labelsuJ (I71:1526;222:119)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 173*fem,
                                                height: 24*fem,
                                                child: Text(
                                                  'When device is locked',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.5*ffem/fem,
                                                    letterSpacing: 0.16*fem,
                                                    color: Color(0xff263238),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // captionmjn (I71:1526;222:120)
                                            left: 0*fem,
                                            top: 15*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 197*fem,
                                                height: 20*fem,
                                                child: Text(
                                                  'Show the notification content',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.4285714286*ffem/fem,
                                                    letterSpacing: 0.07*fem,
                                                    color: Color(0xff263238),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // autogroupymw6FQ4 (R1YMw3K5Fjt5jBNQ4BYMw6)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                      padding: EdgeInsets.fromLTRB(0*fem, 10*fem, 0*fem, 2*fem),
                                      child: Align(
                                        // switchmtC (I71:1526;222:182)
                                        alignment: Alignment.bottomCenter,
                                        child: SizedBox(
                                          width: 40*fem,
                                          height: 20*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/switch-Fqz.png',
                                            width: 40*fem,
                                            height: 20*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // J7S (71:1523)
                            padding: EdgeInsets.fromLTRB(0*fem, 16*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            height: 77*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // defaultdoublesubtitledRhr (71:1524)
                              width: double.infinity,
                              height: 62*fem,
                              child: Container(
                                // autogroupijjcnHW (R1YMPJix8uUzftDbKsiJJc)
                                width: double.infinity,
                                height: 61*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // subtitlevec (I71:1524;222:238)
                                      left: 16*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 129*fem,
                                          height: 16*fem,
                                          child: Text(
                                            'Optional selection title',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w500,
                                              height: 1.3333333333*ffem/fem,
                                              color: Color(0xff263238),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // labelDtc (I71:1524;222:224)
                                      left: 16*fem,
                                      top: 17*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 167*fem,
                                          height: 24*fem,
                                          child: Text(
                                            'When device is locked',
                                            style: SafeGoogleFont (
                                              'Roboto',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.5*ffem/fem,
                                              letterSpacing: 0.4399999976*fem,
                                              color: Color(0xff263238),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // captionumS (I71:1524;222:225)
                                      left: 16*fem,
                                      top: 40*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 197*fem,
                                          height: 20*fem,
                                          child: Text(
                                            'Show the notification content',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.4285714286*ffem/fem,
                                              letterSpacing: 0.07*fem,
                                              color: Color(0xff263238),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // switchcfr (I71:1524;222:228)
                                      left: 321*fem,
                                      top: 27*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 40*fem,
                                          height: 20*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/switch.png',
                                            width: 40*fem,
                                            height: 20*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group2088Q (71:1360)
              left: 6*fem,
              top: 53*fem,
              child: Container(
                width: 415*fem,
                height: 56*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // topdefaultTRa (71:1361)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(271*fem, 8*fem, 8*fem, 8*fem),
                        width: 415*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.only (
                            bottomRight: Radius.circular(8*fem),
                            bottomLeft: Radius.circular(8*fem),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 6*fem,
                            ),
                            BoxShadow(
                              color: Color(0x05000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x02000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconright1FcL (I71:1361;486:3093)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-1-8Gx.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright2MfN (I71:1361;486:3094)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-2-D28.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright3stc (I71:1361;486:3095)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-3-TBN.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // iconleft1jv (71:1362)
                      left: 4*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-left-kWC.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // labelJDE (71:1363)
              left: 46.5*fem,
              top: 66.5*fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 69*fem,
                    height: 28*fem,
                    child: Text(
                      'Setting',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.4*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xff263238),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // msW (71:1364)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupli8gW4Q (R1YQcP1uVZGDH9KNmxLi8g)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogrouprf3vdPv (R1YQhNsaX6BAsv2xAbrf3v)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination1KnY (I71:1364;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff1f1f1),
                            ),
                            child: Container(
                              // bnitem4EL (I71:1364;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconaTa (I71:1364;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-Rc4.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelH76 (I71:1364;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff858585),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupyawacQG (R1YQp3M9DoPnLwf428Yawa)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemLbA (I71:1364;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icon41N (I71:1364;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-sg4.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelni4 (I71:1364;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitemjdJ (I71:1364;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icon4vU (I71:1364;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-DoE.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelzJL (I71:1364;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbar7tk (71:1365)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timepHN (I71:1365;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsXxU (I71:1365;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-PyJ.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}