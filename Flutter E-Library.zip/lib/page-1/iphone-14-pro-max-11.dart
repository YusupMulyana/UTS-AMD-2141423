import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax11frG (56:1093)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // yrx (56:885)
              left: 6*fem,
              top: 103*fem,
              child: Container(
                width: 415*fem,
                height: 773*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x19000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 4*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 2*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x28000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 1*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // exposedflatnZW (I56:890;257:78145)
                      left: 0*fem,
                      top: 193*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16*fem, 4*fem, 8*fem, 4*fem),
                        width: 415*fem,
                        height: 32*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // labelsax (I56:890;257:78145;257:77665)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 281*fem, 0*fem),
                              child: Text(
                                'Kotak Masuk',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.4285714286*ffem/fem,
                                  letterSpacing: 0.07*fem,
                                  color: Color(0xff263238),
                                ),
                              ),
                            ),
                            Container(
                              // iconrightZya (I56:890;257:78145;257:75957)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-rhW.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // exposedflatVMS (I59:1318;257:78145)
                      left: 0*fem,
                      top: 157*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                        width: 415*fem,
                        height: 32*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // dividernrL (56:891)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                              width: 415*fem,
                              height: 1*fem,
                              child: Image.asset(
                                'assets/page-1/images/divider.png',
                                width: 415*fem,
                                height: 1*fem,
                              ),
                            ),
                            Container(
                              // autogroupbsxzuRA (R1YJtJ4F5zPWh7V55aBSXz)
                              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 8*fem, 0*fem),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // label2Vn (I59:1318;257:78145;257:77665)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 259*fem, 0*fem),
                                    child: Text(
                                      'Bacaan Terakhir',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.4285714286*ffem/fem,
                                        letterSpacing: 0.07*fem,
                                        color: Color(0xff263238),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // iconrightjQC (I59:1318;257:78145;257:75957)
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-right-QHn.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // exposedflatsFW (I56:892;257:78145)
                      left: 0*fem,
                      top: 241*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16*fem, 4*fem, 8*fem, 4*fem),
                        width: 415*fem,
                        height: 32*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // labelNCG (I56:892;257:78145;257:77665)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 239*fem, 0*fem),
                              child: Text(
                                'Akun & Pengaturan',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.4285714286*ffem/fem,
                                  letterSpacing: 0.07*fem,
                                  color: Color(0xff263238),
                                ),
                              ),
                            ),
                            Container(
                              // iconright5sN (I56:892;257:78145;257:75957)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-eUY.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // exposedflatDCt (I56:893;257:78145)
                      left: 0*fem,
                      top: 277*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16*fem, 4*fem, 8*fem, 4*fem),
                        width: 415*fem,
                        height: 32*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // labelubW (I56:893;257:78145;257:77665)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 211*fem, 0*fem),
                              child: Text(
                                'Bantuan & Umpan Balik',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.4285714286*ffem/fem,
                                  letterSpacing: 0.07*fem,
                                  color: Color(0xff263238),
                                ),
                              ),
                            ),
                            Container(
                              // iconright1Pe (I56:893;257:78145;257:75957)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-gAL.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // exposedflatwYC (I56:894;257:77684)
                      left: 0*fem,
                      top: 313*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16*fem, 6*fem, 16*fem, 6*fem),
                        width: 415*fem,
                        height: 32*fem,
                        child: Text(
                          'Line spacing',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.4285714286*ffem/fem,
                            letterSpacing: 0.07*fem,
                            color: Color(0xff263238),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // dividerbck (56:895)
                      left: 0*fem,
                      top: 354*fem,
                      child: Align(
                        child: SizedBox(
                          width: 415*fem,
                          height: 1*fem,
                          child: Image.asset(
                            'assets/page-1/images/divider-NG8.png',
                            width: 415*fem,
                            height: 1*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // exposedflatJXA (I56:896;257:78145)
                      left: 0*fem,
                      top: 361*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(16*fem, 4*fem, 8*fem, 4*fem),
                        width: 415*fem,
                        height: 32*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // labelQKJ (I56:896;257:78145;257:77665)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 258*fem, 0*fem),
                              child: Text(
                                'Clear formatting',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.4285714286*ffem/fem,
                                  letterSpacing: 0.07*fem,
                                  color: Color(0xff263238),
                                ),
                              ),
                            ),
                            Opacity(
                              // closeroundmp4 (I56:896;257:78145;257:75957)
                              opacity: 0.54,
                              child: Container(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/close-round.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // scC (56:1235)
                      left: 0*fem,
                      top: 83*fem,
                      child: Container(
                        width: 207*fem,
                        height: 50*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Container(
                          // defaultsingleiconized1TW (I56:1235;223:70099)
                          width: double.infinity,
                          height: double.infinity,
                          child: Container(
                            // autogroupv8jlZzp (R1YKPs3JptnrKg4PojV8JL)
                            padding: EdgeInsets.fromLTRB(16*fem, 5*fem, 16*fem, 4*fem),
                            width: double.infinity,
                            height: 49*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupz3rjHR2 (R1YKXmynnVEhgtrtWRZ3RJ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  width: 40*fem,
                                  height: double.infinity,
                                  child: Container(
                                    // avatarDJg (I56:1235;223:70099;221:2247)
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                    ),
                                    child: Opacity(
                                      // misciconsbackgroundLu6 (I56:1235;223:70099;221:2247;0:235)
                                      opacity: 0.38,
                                      child: Container(
                                        width: double.infinity,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          border: Border.all(color: Color(0xff3a4e58)),
                                          borderRadius: BorderRadius.circular(999*fem),
                                          image: DecorationImage (
                                            fit: BoxFit.cover,
                                            image: AssetImage (
                                              'assets/page-1/images/icons-button-bg.png',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupeyjxjRS (R1YKeSTMVCTK9vUzMxEyJx)
                                  margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                                  width: 119*fem,
                                  height: double.infinity,
                                  child: Text(
                                    'Yusup Mulyana',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      letterSpacing: 0.16*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group201dr (59:1477)
              left: 6*fem,
              top: 53*fem,
              child: Container(
                width: 415*fem,
                height: 56*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // topdefaultwGc (56:1094)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(271*fem, 8*fem, 8*fem, 8*fem),
                        width: 415*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.only (
                            bottomRight: Radius.circular(8*fem),
                            bottomLeft: Radius.circular(8*fem),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 6*fem,
                            ),
                            BoxShadow(
                              color: Color(0x05000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x02000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconright1jTN (I56:1094;486:3093)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-1-5Hz.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright23ix (I56:1094;486:3094)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-2-mZr.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright3AYg (I56:1094;486:3095)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-3-QAU.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // iconlefttUg (59:1457)
                      left: 4*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-left-GkG.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // labelPwE (69:1135)
              left: 43*fem,
              top: 66.5*fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 183*fem,
                    height: 28*fem,
                    child: Text(
                      'User and Accounts',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.4*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xff263238),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // 5p4 (56:1120)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupie3ipFr (R1YLBg4JuHAJejxqYzie3i)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogroupgbjy9Z2 (R1YLHRPjUwcQbEBrFYGBJY)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination1dyz (I56:1120;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff1f1f1),
                            ),
                            child: Container(
                              // bnitemNRn (I56:1120;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconhDA (I56:1120;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-KC4.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelpHn (I56:1120;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff858585),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupx7ccxPz (R1YLQ5sJBeq24Fox74x7CC)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemfpC (I56:1120;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconyZz (I56:1120;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-CoJ.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelhkt (I56:1120;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitemqcC (I56:1120;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconZHJ (I56:1120;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-9Kv.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelg72 (I56:1120;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarQoi (56:1095)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeuVa (I56:1095;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonscet (I56:1095;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-UPi.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // buttonWVN (56:1307)
              left: 182*fem,
              top: 803*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 89*fem,
                  height: 36*fem,
                  decoration: BoxDecoration (
                    border: Border.all(color: Color(0x44000000)),
                    color: Color(0x60525658),
                    borderRadius: BorderRadius.circular(5*fem),
                  ),
                  child: Center(
                    child: Text(
                      'Log out',
                      style: SafeGoogleFont (
                        'Kanit',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w300,
                        height: 1.495*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}