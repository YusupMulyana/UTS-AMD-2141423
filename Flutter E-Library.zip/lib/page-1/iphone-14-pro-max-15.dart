import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax15gWL (71:1631)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // backgroundBCC (71:1632)
              left: 7*fem,
              top: 115*fem,
              child: Align(
                child: SizedBox(
                  width: 415*fem,
                  height: 769*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(8*fem),
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x19000000),
                          offset: Offset(0*fem, 1*fem),
                          blurRadius: 4*fem,
                        ),
                        BoxShadow(
                          color: Color(0x1e000000),
                          offset: Offset(0*fem, 2*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x28000000),
                          offset: Offset(0*fem, 1*fem),
                          blurRadius: 1*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // 8Fr (71:1859)
              left: 18*fem,
              top: 147*fem,
              child: Container(
                width: 377*fem,
                height: 44*fem,
                decoration: BoxDecoration (
                  color: Color(0xfff0f0f0),
                  borderRadius: BorderRadius.circular(8*fem),
                ),
                child: Container(
                  // defaultsingleiconizedeV6 (I71:1859;71:1528)
                  width: double.infinity,
                  height: double.infinity,
                  child: Container(
                    // autogroupcrdsQDN (R1YRjRyr7wkMfaagmucRDS)
                    padding: EdgeInsets.fromLTRB(16*fem, 2*fem, 10*fem, 1*fem),
                    width: double.infinity,
                    height: 43*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroup9xxnWnC (R1YRt1ZtMD7fn6wnrx9XXN)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                          width: 40*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // iconleftqJg (I71:1859;71:1531)
                                left: 8*fem,
                                top: 8*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-left-b7n.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // imgw6p (I71:1859;71:1536)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 40*fem,
                                    height: 40*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(2*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/img-sur.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // labelHZz (I71:1859;71:1537)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 106*fem, 0*fem),
                          child: Text(
                            'Kumpulan Sampah',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              letterSpacing: 0.16*fem,
                              color: Color(0xff263238),
                            ),
                          ),
                        ),
                        Container(
                          // autogroup1sll9s6 (R1YRyWQj5ViiwMLKns1sLL)
                          margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                          padding: EdgeInsets.fromLTRB(17*fem, 0*fem, 0*fem, 0*fem),
                          height: double.infinity,
                          child: Align(
                            // iconrightso6 (71:1860)
                            alignment: Alignment.centerRight,
                            child: SizedBox(
                              width: 29*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-Ufz.png',
                                width: 29*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group20Zvp (71:1639)
              left: 6*fem,
              top: 53*fem,
              child: Container(
                width: 415*fem,
                height: 56*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // topdefaulttiC (71:1640)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(271*fem, 8*fem, 8*fem, 8*fem),
                        width: 415*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.only (
                            bottomRight: Radius.circular(8*fem),
                            bottomLeft: Radius.circular(8*fem),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 6*fem,
                            ),
                            BoxShadow(
                              color: Color(0x05000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x02000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconright1t5v (I71:1640;486:3093)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-1-pdn.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright2N16 (I71:1640;486:3094)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-2-q36.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright3fkt (I71:1640;486:3095)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-3-zVv.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // iconleftn4p (71:1641)
                      left: 4*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-left-Kda.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // labelEhW (71:1642)
              left: 48*fem,
              top: 66.5*fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 111*fem,
                    height: 28*fem,
                    child: Text(
                      'Recycle Bin',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.4*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xff263238),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // hqz (71:1643)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupkj1adUk (R1YSXppDBYRb9Y6uyykj1A)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogroupigmnxmv (R1YScjqgvcis9tsfT5iGmn)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination1oXe (I71:1643;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff1f1f1),
                            ),
                            child: Container(
                              // bnitemKVz (I71:1643;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // icone2U (I71:1643;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-nXz.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // label9E8 (I71:1643;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff858585),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupqowp5Ng (R1YSjKV4LsKo2WYwP4qoWp)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemnH6 (I71:1643;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconspL (I71:1643;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-Fpt.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelDNQ (I71:1643;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitemkNL (I71:1643;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconH7N (I71:1643;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-59z.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labeloLc (I71:1643;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarwSp (71:1644)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // time3Vr (I71:1644;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonskv4 (I71:1644;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-Pmr.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}