import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax7T3N (47:485)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupstxnwz8 (R1YZ8JVaGjWHhLq7CYsTXN)
              left: 6*fem,
              top: 109*fem,
              child: Container(
                width: 1016*fem,
                height: 767*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // frame7rrC (47:487)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 415*fem,
                        height: 767*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xffffffff)),
                          color: Color(0x93ff3d00),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // backgroundNZe (47:488)
                              left: 10*fem,
                              top: 2.6154785156*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 394*fem,
                                  height: 764.38*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(20*fem),
                                      border: Border.all(color: Color(0x93ff3d00)),
                                      color: Color(0xaa565656),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // background5U4 (47:489)
                              left: 26*fem,
                              top: 109*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 360*fem,
                                  height: 454*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xffffffff)),
                                      color: Color(0xff9f9898),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // group11ndN (47:490)
                      left: 26*fem,
                      top: 118*fem,
                      child: Container(
                        width: 990*fem,
                        height: 444.53*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // autogrouphm6xWpG (R1YZJiMtk6QcrwzPbZhM6x)
                              margin: EdgeInsets.fromLTRB(112*fem, 0*fem, 0*fem, 10.24*fem),
                              width: 141*fem,
                              height: 190.29*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // backgrounde9n (47:491)
                                    left: 6*fem,
                                    top: 7.6589355469*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 135*fem,
                                        height: 182.63*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(20*fem),
                                            border: Border.all(color: Color(0xffffffff)),
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // backgroundXjN (47:492)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 135*fem,
                                        height: 182.63*fem,
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(20*fem),
                                          child: Image.asset(
                                            'assets/page-1/images/background-Bcc.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // textonlytestimonialRJx (I47:493;39:449)
                              width: double.infinity,
                              height: 244*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // backgroundwYC (I47:493;39:449;391:2812)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 360*fem,
                                        height: 244*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(4*fem),
                                            color: Color(0xffffffff),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0x19000000),
                                                offset: Offset(0*fem, 1*fem),
                                                blurRadius: 4*fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x1e000000),
                                                offset: Offset(0*fem, 2*fem),
                                                blurRadius: 2*fem,
                                              ),
                                              BoxShadow(
                                                color: Color(0x28000000),
                                                offset: Offset(0*fem, 1*fem),
                                                blurRadius: 1*fem,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // imgP9J (I47:493;39:449;391:2805;255:4183;0:401)
                                    left: 16*fem,
                                    top: 16*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 40*fem,
                                        height: 40*fem,
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(9999*fem),
                                          child: Image.asset(
                                            'assets/page-1/images/img-WgQ.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // thumbdownUgY (I47:493;39:449;391:2769)
                                    left: 264*fem,
                                    top: 16*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 40*fem,
                                        height: 40*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/thumb-down-Pje.png',
                                          width: 40*fem,
                                          height: 40*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // thumbupnBS (I47:493;39:579)
                                    left: 314*fem,
                                    top: 87.4694824219*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 27*fem,
                                        height: 27*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/thumb-up-dya.png',
                                          width: 27*fem,
                                          height: 27*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // ratingu1A (I47:493;39:557)
                                    left: 8.5*fem,
                                    top: 96.9694824219*fem,
                                    child: Container(
                                      width: 147.5*fem,
                                      height: 24*fem,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroup2vktpdv (R1Ya37JvBfZ5s68xVX2Vkt)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.5*fem, 0*fem),
                                            width: 82*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-2vkt.png',
                                              width: 82*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                          Text(
                                            // valueL6U (I47:493;39:557;255:4627)
                                            '3 days ago',
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w500,
                                              height: 1.3333333333*ffem/fem,
                                              color: Color(0xff263238),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // bodyExY (I47:493;39:556)
                                    left: 13*fem,
                                    top: 125.4694824219*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 327*fem,
                                        height: 80*fem,
                                        child: Text(
                                          'Text labels need to be distinct from other elements. If the text label isn’t capitalized, it should use a different color, style, or layout from other text.',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.4285714286*ffem/fem,
                                            letterSpacing: 0.07*fem,
                                            color: Color(0xff263238),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // thumbdownvKa (I47:493;39:552)
                                    left: 276*fem,
                                    top: 94.4694824219*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 28*fem,
                                        height: 30*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/thumb-down-b8k.png',
                                          width: 28*fem,
                                          height: 30*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // titleSHv (I47:493;39:550)
                                    left: 64*fem,
                                    top: 11.4694824219*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 266*fem,
                                        height: 48*fem,
                                        child: Text(
                                          'SISTEM INFORMASI ANALISA DAN PERANCANGAN',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            letterSpacing: 0.16*fem,
                                            color: Color(0xff263238),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // counterLPJ (I47:493;39:551)
                                    left: 64*fem,
                                    top: 63.4694824219*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 84*fem,
                                        height: 20*fem,
                                        child: Text(
                                          '5K READING',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.4285714286*ffem/fem,
                                            letterSpacing: 0.07*fem,
                                            color: Color(0xff263238),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // importcLp (I47:493;41:619)
                                    left: 314*fem,
                                    top: 214.4694824219*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/import-jKv.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // backgroundv6c (48:671)
                      left: 42*fem,
                      top: 64*fem,
                      child: Align(
                        child: SizedBox(
                          width: 332*fem,
                          height: 531*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                              border: Border.all(color: Color(0xffffffff)),
                              color: Color(0xaa565656),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // emptystatepositive2QY (48:636)
              left: 62*fem,
              top: 218*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(18*fem, 0*fem, 18*fem, 98*fem),
                width: 306*fem,
                height: 454*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // bodyioA (48:637)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 40*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // placeholderTEx (48:638)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 11.5*fem),
                            width: 148*fem,
                            height: 148*fem,
                            child: Image.asset(
                              'assets/page-1/images/placeholder.png',
                              width: 148*fem,
                              height: 148*fem,
                            ),
                          ),
                          Center(
                            // h49Ng (48:639)
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7.5*fem),
                              child: Text(
                                'Successful state!',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'IBM Plex Sans',
                                  fontSize: 34*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2999999102*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                          Center(
                            // textdoe (48:640)
                            child: Container(
                              constraints: BoxConstraints (
                                maxWidth: 270*fem,
                              ),
                              child: Text(
                                'You have reached your maximum prototyping speed',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'IBM Plex Sans',
                                  fontSize: 20*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.3800000191*ffem/fem,
                                  letterSpacing: 0.15*fem,
                                  color: Color(0xff818181),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // buttonsKwN (48:641)
                      margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 32*fem, 0*fem),
                      width: double.infinity,
                      height: 48*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // btnoutlinedmasterrwJ (48:642)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                            width: 88*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffc0c0c0)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(8*fem),
                            ),
                            child: Container(
                              // bodyN8x (I48:642;17:58)
                              padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 16*fem, 12*fem),
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Container(
                                // autogroupchp67MS (R1Yb1VrdJL4EYb6LUtChP6)
                                width: double.infinity,
                                height: double.infinity,
                                child: Center(
                                  child: Text(
                                    'CANCEL',
                                    style: SafeGoogleFont (
                                      'IBM Plex Sans',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      letterSpacing: 0.8*fem,
                                      color: Color(0xff818181),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // btncontainedmasteroVA (48:643)
                            width: 102*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xff1f8b24),
                              borderRadius: BorderRadius.circular(8*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x33616161),
                                  offset: Offset(0*fem, 2*fem),
                                  blurRadius: 2*fem,
                                ),
                                BoxShadow(
                                  color: Color(0x33616161),
                                  offset: Offset(0*fem, 1*fem),
                                  blurRadius: 1*fem,
                                ),
                              ],
                            ),
                            child: Container(
                              // bodygJ4 (I48:643;62:240)
                              padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 20*fem, 12*fem),
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Container(
                                // autogroup31uaDHz (R1Yb95UL863MYA7XVQ31ua)
                                width: double.infinity,
                                height: double.infinity,
                                child: Center(
                                  child: Text(
                                    ' CONFIRM',
                                    style: SafeGoogleFont (
                                      'IBM Plex Sans',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.5*ffem/fem,
                                      letterSpacing: 0.8*fem,
                                      color: Color(0xffc5f2c7),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // containericonleft7eG (47:494)
              left: 6*fem,
              top: 65*fem,
              child: Container(
                width: 415*fem,
                height: 44*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x19000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 4*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 2*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x28000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 1*fem,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      // iconleftYUg (I47:494;108:1389)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 80*fem,
                          height: 44*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-left-icg.png',
                            width: 80*fem,
                            height: 44*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // labeleGp (47:495)
                      left: 66.5*fem,
                      top: 7.5714111328*fem,
                      child: Center(
                        child: Align(
                          child: SizedBox(
                            width: 338*fem,
                            height: 28*fem,
                            child: Text(
                              'Buku Sistem Informasi Analisan ....',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.4*ffem/fem,
                                letterSpacing: 0.150000006*fem,
                                color: Color(0xff263238),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // Kdr (47:496)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupbh6qSCg (R1YbN56gPg1r6ZaRWHBH6Q)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogrouplq7vAPa (R1YbSZyBiTEi8rd3MfLq7v)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination1rnC (I47:496;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                            ),
                            child: Container(
                              // bnitemay6 (I47:496;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconK9z (I47:496;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-ADN.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelEXr (I47:496;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogrouptnnkaLp (R1YbYKJcJ7gp5Lr44CtNNk)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemJXi (I47:496;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconD8t (I47:496;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-P6p.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // label9YL (I47:496;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitemhJx (I47:496;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icondTW (I47:496;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-Ekx.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // label9Ax (I47:496;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarff6 (47:497)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeMnp (I47:497;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonssmA (I47:497;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-T92.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}