import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax2BV2 (20:89)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // statusbariE4 (34:758)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
              padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xfffcfcff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timecKS (I34:758;102:1072)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                    child: Text(
                      '9:30',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xff1e1e1e),
                      ),
                    ),
                  ),
                  Container(
                    // righticonsJxx (I34:758;102:1074)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                    width: 46*fem,
                    height: 17*fem,
                    child: Image.asset(
                      'assets/page-1/images/right-icons-MxC.png',
                      width: 46*fem,
                      height: 17*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupbmfnzat (R1XzqZdMuCwjNq9SYhBmfn)
              width: 1670*fem,
              height: 868*fem,
              child: Stack(
                children: [
                  Positioned(
                    // mainXap (20:91)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(10*fem, 10*fem, 10*fem, 10*fem),
                      width: 434*fem,
                      height: 868*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(20*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Align(
                        // perpus1o2Y (I20:91;19:78)
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          width: 414*fem,
                          height: 812*fem,
                          child: Image.asset(
                            'assets/page-1/images/perpus-1-KWp.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // XjE (20:92)
                    left: 0*fem,
                    top: 286*fem,
                    child: Container(
                      width: 1668*fem,
                      height: 582*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupk3nqFQL (R1Y13iwmLCmQ17A5L8k3NQ)
                            margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                            width: 1550*fem,
                            height: 28*fem,
                          ),
                          Container(
                            // autogroupppsgn9N (R1Y18oddeCJ3CHpUeKpPSG)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: 56*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(8*fem),
                                topRight: Radius.circular(8*fem),
                              ),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemGKS (I20:92;12:37;371:4252)
                                  padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconb6p (I20:92;12:37;371:4252;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-sVi.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labeluNQ (I20:92;12:37;371:4252;371:4246)
                                        'Dashboard',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff858585),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // bnitemcGp (I20:92;12:38;371:4765)
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconXeg (I20:92;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-Qbi.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelTHS (I20:92;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // bnitemMNp (I20:92;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconsrx (I20:92;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-Mwn.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labeloVi (I20:92;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group68Xz (27:409)
                    left: 72*fem,
                    top: 250*fem,
                    child: Container(
                      width: 279*fem,
                      height: 325*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(20*fem),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // backgroundqxC (21:471)
                            left: 6*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 273*fem,
                                height: 325*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(20*fem),
                                    border: Border.all(color: Color(0xffffffff)),
                                    color: Color(0xaa565656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // labeljng (27:407)
                            left: 21*fem,
                            top: 287.5*fem,
                            child: Center(
                              child: Align(
                                child: SizedBox(
                                  width: 143*fem,
                                  height: 28*fem,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 2.3333333333*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xffffffff),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: '*',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 2.3333333333*ffem/fem,
                                            letterSpacing: 0.150000006*fem,
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'Please choose to enter',
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group5W4g (27:408)
                            left: 17*fem,
                            top: 15*fem,
                            child: Container(
                              width: 247*fem,
                              height: 46*fem,
                              decoration: BoxDecoration (
                                border: Border.all(color: Color(0xffffffff)),
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(20*fem),
                              ),
                              child: Center(
                                child: Center(
                                  child: Text(
                                    'HIi, Welcome',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 23*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2173913043*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // largebuttoniconw9z (23:356)
                            left: 83*fem,
                            top: 122*fem,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(19*fem, 12*fem, 12*fem, 13*fem),
                              width: 120*fem,
                              height: 52*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(5*fem),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupkdziztx (R1Y1jcxxG1TPCrwrXmKDZi)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                    width: 54*fem,
                                    height: double.infinity,
                                    child: Center(
                                      child: Text(
                                        'Sign in',
                                        style: SafeGoogleFont (
                                          'Kanit',
                                          fontSize: 18*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.495*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // exittoappGrU (26:383)
                                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/exittoapp.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // largebuttoniconkme (26:387)
                            left: 83*fem,
                            top: 217*fem,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(19*fem, 11*fem, 9*fem, 14*fem),
                              width: 120*fem,
                              height: 52*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(5*fem),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupskmrERv (R1Y1u2rwKryXFWmDrFSKMr)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                    width: 59*fem,
                                    height: double.infinity,
                                    child: Center(
                                      child: Text(
                                        'Sign up',
                                        style: SafeGoogleFont (
                                          'Kanit',
                                          fontSize: 18*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.495*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // autogrouplgtj6j2 (R1Y1xSvuxgCWaSX6hZLgTJ)
                                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                                    padding: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
                                    width: 30*fem,
                                    height: 24*fem,
                                    child: Container(
                                      // group2cSU (27:404)
                                      width: double.infinity,
                                      height: double.infinity,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // postaddAit (27:391)
                                            left: 0*fem,
                                            top: 0*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 24*fem,
                                                height: 24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/postadd.png',
                                                  width: 24*fem,
                                                  height: 24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // modeUja (27:401)
                                            left: 8*fem,
                                            top: 3*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 13*fem,
                                                height: 14*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/mode.png',
                                                  width: 13*fem,
                                                  height: 14*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}