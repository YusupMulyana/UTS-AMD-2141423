import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax10fP6 (51:911)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // topdefaultAqe (51:936)
              left: 6*fem,
              top: 53*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                width: 415*fem,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.only (
                    bottomRight: Radius.circular(8*fem),
                    bottomLeft: Radius.circular(8*fem),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 6*fem,
                    ),
                    BoxShadow(
                      color: Color(0x05000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 4*fem,
                    ),
                    BoxShadow(
                      color: Color(0x02000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // iconleftuwe (I51:936;486:3092)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 223*fem, 0*fem),
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-left-GN4.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // iconright1pYp (I51:936;486:3093)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-right-1-FA8.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // iconright2LGG (I51:936;486:3094)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-right-2-qxk.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // iconright3f3e (I51:936;486:3095)
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-right-3-m1a.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarC3a (51:938)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeHqi (I51:938;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsnXa (I51:938;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-2EU.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame76YG (51:913)
              left: 6*fem,
              top: 103*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(38*fem, 4.99*fem, 33*fem, 77.07*fem),
                width: 415*fem,
                height: 1173*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0x93ff3d00),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // line1YfA (51:935)
                      margin: EdgeInsets.fromLTRB(169*fem, 0*fem, 174*fem, 28.8*fem),
                      width: double.infinity,
                      height: 2*fem,
                      decoration: BoxDecoration (
                        color: Color(0x93ff3d00),
                      ),
                    ),
                    Container(
                      // autogroupwlxxfDz (R1YAcHM4hStSMrqKpqwLxx)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48.68*fem),
                      width: double.infinity,
                      height: 172.88*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupi3snP9z (R1YAmCFt4YiUr2yjc4i3sN)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                            width: 144*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundWVW (51:915)
                                  left: 9*fem,
                                  top: 5.9614257812*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundQ56 (51:916)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-kAc.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupkckgHua (R1YAqcJC6sKfHv5XXuKCkG)
                            width: 143*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundeEL (51:933)
                                  left: 8*fem,
                                  top: 5.9614257812*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // background9gt (51:934)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-beg.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouphvrnGFi (R1YAyGk6D5vTsu3YTxhvRN)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48.68*fem),
                      width: double.infinity,
                      height: 172.88*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupxftePr8 (R1YB623rCFkkwLcUF2xFTe)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0.99*fem),
                            width: 144*fem,
                            height: 171.89*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // background832 (51:917)
                                  left: 9*fem,
                                  top: 4.9677734375*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundpRe (51:918)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-X2x.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupmq5e56g (R1YBArF8esSMMHSPnbMQ5e)
                            width: 143*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundb52 (51:931)
                                  left: 8*fem,
                                  top: 5.9614257812*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundHyS (51:932)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-V3e.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouprv3zogt (R1YBJgMRL1GX86J4Zjrv3z)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 47.69*fem),
                      width: double.infinity,
                      height: 173.87*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupkfmaX76 (R1YBR1WCtt2QDU8rj6KFMA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                            width: 144*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundexQ (51:920)
                                  left: 9*fem,
                                  top: 6.9548339844*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundxCQ (51:921)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-XNg.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupn1beTQ4 (R1YBUWQNp9s58oqZVwn1bE)
                            width: 143*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundQaC (51:919)
                                  left: 8*fem,
                                  top: 6.9548339844*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundX92 (51:930)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-axG.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupplncdSx (R1YBbfs7DcmnAK8ctjpLNc)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 49.68*fem),
                      width: double.infinity,
                      height: 171.89*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupbti8ZLc (R1YBiaqFmhqSQabCWuBTi8)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                            width: 144*fem,
                            height: 170.89*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundtNt (51:922)
                                  left: 9*fem,
                                  top: 3.9680175781*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundnz4 (51:924)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-GoA.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupedsq6jr (R1YBnv3NXZpwG3kAXCEDSQ)
                            width: 143*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundrU8 (51:925)
                                  left: 8*fem,
                                  top: 4.9680175781*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundAUp (51:926)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-sR2.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupv9l4GGx (R1YBuaWwEH3Yj5NGNiv9L4)
                      width: double.infinity,
                      height: 173.87*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupuhsgc5v (R1YC1F2AXUsy59eT9iuHSG)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
                            width: 144*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundwdz (51:923)
                                  left: 9*fem,
                                  top: 6.955078125*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundSak (51:927)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-rTA.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupqesjYdn (R1YC5QZtiRe6jnumJvqEsJ)
                            width: 143*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // backgroundJ7A (51:928)
                                  left: 8*fem,
                                  top: 6.955078125*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(20*fem),
                                          border: Border.all(color: Color(0xffffffff)),
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // backgroundCiL (51:929)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 135*fem,
                                      height: 166.92*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(20*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/background-3SG.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // background86C (51:914)
              left: 16*fem,
              top: 107*fem,
              child: Align(
                child: SizedBox(
                  width: 394*fem,
                  height: 1169*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(20*fem),
                      border: Border.all(color: Color(0x93ff3d00)),
                      color: Color(0xaa565656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // qWQ (51:937)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupcqkcAYg (R1YCitVSQvVHjaHajnCqkc)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogroupdaicJPz (R1YCpUAURfi2VEcwbEdaiC)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination1o5r (I51:937;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff1f1f1),
                            ),
                            child: Container(
                              // bnitemK4C (I51:937;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // icon1hi (I51:937;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-9mz.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelKiQ (I51:937;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff858585),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupcijcSHE (R1YCvxyeZThGmSMPbgCiJc)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemAU8 (I51:937;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconsdS (I51:937;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-EPa.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelp2t (I51:937;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitem9qr (I51:937;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icon5Di (I51:937;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-JyE.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelzLg (I51:937;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group8St (51:881)
              left: 8*fem,
              top: 103*fem,
              child: Container(
                width: 95*fem,
                height: 413*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // autogroupnvvirNt (R1YDwMU2V8xogqzbk6nVVi)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 95*fem,
                        height: 354.34*fem,
                        decoration: BoxDecoration (
                          image: DecorationImage (
                            fit: BoxFit.cover,
                            image: AssetImage (
                              'assets/page-1/images/vector-BeY.png',
                            ),
                          ),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // vectorYFi (51:883)
                              left: 0*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 95*fem,
                                  height: 78.82*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-Qmn.png',
                                    width: 95*fem,
                                    height: 78.82*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector3yA (51:886)
                              left: 40.3750305176*fem,
                              top: 99.3500976562*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 14.25*fem,
                                  height: 4.93*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-x4g.png',
                                    width: 14.25*fem,
                                    height: 4.93*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // autogroupvkjeAH6 (R1YEDBLzQKrWRHbb9UvKje)
                              left: 40.3750305176*fem,
                              top: 105.9184570312*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 14.25*fem,
                                  height: 8.21*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/auto-group-vkje.png',
                                    width: 14.25*fem,
                                    height: 8.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector4NU (51:897)
                              left: 37.5736694336*fem,
                              top: 163.9909667969*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 19*fem,
                                  height: 17.24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-ZCt.png',
                                    width: 19*fem,
                                    height: 17.24*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorN8G (51:898)
                              left: 28*fem,
                              top: 192.9011230469*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 38.43*fem,
                                  height: 8.62*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-onx.png',
                                    width: 38.43*fem,
                                    height: 8.62*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorHW8 (51:906)
                              left: 42*fem,
                              top: 234.2727050781*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 12.67*fem,
                                  height: 6.57*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-5Wg.png',
                                    width: 12.67*fem,
                                    height: 6.57*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorQqe (51:907)
                              left: 43.5833435059*fem,
                              top: 241.6625976562*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 12.67*fem,
                                  height: 6.57*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-dHA.png',
                                    width: 12.67*fem,
                                    height: 6.57*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorXfN (51:908)
                              left: 26*fem,
                              top: 256.1062011719*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 45.93*fem,
                                  height: 11.37*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-zSL.png',
                                    width: 45.93*fem,
                                    height: 11.37*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector49W (51:909)
                              left: 40.0888061523*fem,
                              top: 290.888671875*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 14.25*fem,
                                  height: 15.6*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-RCL.png',
                                    width: 14.25*fem,
                                    height: 15.6*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectormJp (51:910)
                              left: 17*fem,
                              top: 318.5668945312*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 60.48*fem,
                                  height: 11.21*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/vector-ENk.png',
                                    width: 60.48*fem,
                                    height: 11.21*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // kategori66C (51:1007)
                      left: 22.5475921631*fem,
                      top: 122.9689941406*fem,
                      child: Align(
                        child: SizedBox(
                          width: 49*fem,
                          height: 16*fem,
                          child: Text(
                            'Kategori',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              color: Color(0xb5000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // vectorbHr (51:899)
                      left: 43.6828308105*fem,
                      top: 20.0083007812*fem,
                      child: Align(
                        child: SizedBox(
                          width: 6.33*fem,
                          height: 6.57*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-ofE.png',
                            width: 6.33*fem,
                            height: 6.57*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // vectorKDr (51:900)
                      left: 38.1411743164*fem,
                      top: 16.7236328125*fem,
                      child: Align(
                        child: SizedBox(
                          width: 17.42*fem,
                          height: 18.06*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-zuE.png',
                            width: 17.42*fem,
                            height: 18.06*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // vectorqT6 (51:901)
                      left: 20.8095092773*fem,
                      top: 46.216796875*fem,
                      child: Align(
                        child: SizedBox(
                          width: 52.02*fem,
                          height: 24.88*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-rsA.png',
                            width: 52.02*fem,
                            height: 24.88*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // vectorMgL (51:903)
                      left: 46.7083740234*fem,
                      top: 408.0734863281*fem,
                      child: Align(
                        child: SizedBox(
                          width: 1.58*fem,
                          height: 4.93*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-bzp.png',
                            width: 1.58*fem,
                            height: 4.93*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}