import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax3gDv (29:153)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // statusbaroJY (34:744)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
              padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xfffcfcff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timetKz (I34:744;102:1072)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                    child: Text(
                      '9:30',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xff1e1e1e),
                      ),
                    ),
                  ),
                  Container(
                    // righticonsysE (I34:744;102:1074)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                    width: 46*fem,
                    height: 17*fem,
                    child: Image.asset(
                      'assets/page-1/images/right-icons.png',
                      width: 46*fem,
                      height: 17*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup7jtwtjJ (R1Y2r1HLcj24qzeZ9N7jTW)
              width: 1670*fem,
              height: 868*fem,
              child: Stack(
                children: [
                  Positioned(
                    // maindgt (29:155)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(10*fem, 10*fem, 10*fem, 10*fem),
                      width: 434*fem,
                      height: 868*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(20*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Align(
                        // perpus1HmS (I29:155;19:78)
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          width: 414*fem,
                          height: 812*fem,
                          child: Image.asset(
                            'assets/page-1/images/perpus-1-Tqr.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // Qr4 (29:156)
                    left: 0*fem,
                    top: 286*fem,
                    child: Container(
                      width: 1668*fem,
                      height: 582*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupj1vpiLx (R1Y32v8pnqcVa5Uo5eJ1vp)
                            margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 426*fem),
                            width: 1550*fem,
                            height: 28*fem,
                          ),
                          Container(
                            // qwN (34:580)
                            margin: EdgeInsets.fromLTRB(124*fem, 0*fem, 0*fem, 28*fem),
                            width: 179*fem,
                            height: 44*fem,
                            child: Container(
                              // containericonleftzJU (34:581)
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration (
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(8*fem),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x19000000),
                                    offset: Offset(0*fem, 1*fem),
                                    blurRadius: 4*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x1e000000),
                                    offset: Offset(0*fem, 2*fem),
                                    blurRadius: 2*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x28000000),
                                    offset: Offset(0*fem, 1*fem),
                                    blurRadius: 1*fem,
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    // iconleftSgG (I34:581;108:1389)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 80*fem,
                                        height: 44*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-left-3bv.png',
                                          width: 80*fem,
                                          height: 44*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // labelYDW (I34:581;108:1388)
                                    left: 65*fem,
                                    top: 8*fem,
                                    child: Center(
                                      child: Align(
                                        child: SizedBox(
                                          width: 49*fem,
                                          height: 28*fem,
                                          child: Text(
                                            'Back',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Inter',
                                              fontSize: 20*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.4*ffem/fem,
                                              letterSpacing: 0.150000006*fem,
                                              color: Color(0xff263238),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupnmzgoQL (R1Y37zph6q98mG9CPqNMzg)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: 56*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(8*fem),
                                topRight: Radius.circular(8*fem),
                              ),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemJ6C (I29:156;12:37;371:4252)
                                  padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconQf2 (I29:156;12:37;371:4252;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-p48.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelurg (I29:156;12:37;371:4252;371:4246)
                                        'Dashboard',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff858585),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // bnitemdXn (I29:156;12:38;371:4765)
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconAGp (I29:156;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-wW8.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelgkx (I29:156;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // bnitembsv (I29:156;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconixY (I29:156;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-FDz.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelER6 (I29:156;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group6NGQ (29:157)
                    left: 48*fem,
                    top: 122*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(10.71*fem, 22*fem, 11*fem, 17*fem),
                      width: 331.71*fem,
                      height: 560*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xaa565656),
                        borderRadius: BorderRadius.circular(20*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group5dTE (29:160)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                            width: double.infinity,
                            height: 46*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffffffff)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'Create your account now',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 23*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2173913043*ffem/fem,
                                    letterSpacing: 0.150000006*fem,
                                    color: Color(0xb5000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // group7FDi (29:232)
                            padding: EdgeInsets.fromLTRB(12*fem, 9.14*fem, 14*fem, 28*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffffffff)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // labelJSt (29:241)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.79*fem),
                                  child: Text(
                                    'Nama :',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // backgroundbRz (29:236)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24.57*fem),
                                  width: double.infinity,
                                  height: 31.76*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    border: Border.all(color: Color(0x30000000)),
                                    color: Color(0x42565656),
                                  ),
                                ),
                                Container(
                                  // labeluSg (29:242)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.79*fem),
                                  child: Text(
                                    'Email :',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // backgroundDyA (29:238)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24.57*fem),
                                  width: double.infinity,
                                  height: 31.76*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    border: Border.all(color: Color(0x30000000)),
                                    color: Color(0x42565656),
                                  ),
                                ),
                                Container(
                                  // labelxA4 (29:243)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.79*fem),
                                  child: Text(
                                    'Password :',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // backgroundsnp (29:239)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24.57*fem),
                                  width: double.infinity,
                                  height: 31.76*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    border: Border.all(color: Color(0x30000000)),
                                    color: Color(0x42565656),
                                  ),
                                ),
                                Container(
                                  // labelQGx (29:244)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.79*fem),
                                  child: Text(
                                    'Confirm Password :',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // backgroundj4L (29:240)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16.97*fem),
                                  width: double.infinity,
                                  height: 31.76*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    border: Border.all(color: Color(0x30000000)),
                                    color: Color(0x42565656),
                                  ),
                                ),
                                Container(
                                  // autogrouptf1ifCt (R1Y3we7yRK3c9QqpT4tf1i)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 212.15*fem, 21.92*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // vectorBS8 (32:552)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.29*fem, 0*fem),
                                        width: 11*fem,
                                        height: 10.08*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector.png',
                                          width: 11*fem,
                                          height: 10.08*fem,
                                        ),
                                      ),
                                      Container(
                                        // group74t (32:553)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.48*fem),
                                        width: 56.55*fem,
                                        height: 7.6*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/group.png',
                                          width: 56.55*fem,
                                          height: 7.6*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // minibuttond3E (32:570)
                                  margin: EdgeInsets.fromLTRB(103.29*fem, 0*fem, 99.71*fem, 0*fem),
                                  width: double.infinity,
                                  height: 40*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(5*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Submit',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Kanit',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.495*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}