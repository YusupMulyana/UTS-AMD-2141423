import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax4Y6C (34:591)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // statusbarFWQ (34:615)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
              padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xfffcfcff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timewPE (I34:615;102:1072)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                    child: Text(
                      '9:30',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xff1e1e1e),
                      ),
                    ),
                  ),
                  Container(
                    // righticonsqDi (I34:615;102:1074)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                    width: 46*fem,
                    height: 17*fem,
                    child: Image.asset(
                      'assets/page-1/images/right-icons-vwJ.png',
                      width: 46*fem,
                      height: 17*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup1ytewnY (R1Y53mwmvemF1Ji3J31yTe)
              width: 1670*fem,
              height: 868*fem,
              child: Stack(
                children: [
                  Positioned(
                    // mainsgC (34:592)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(10*fem, 10*fem, 10*fem, 10*fem),
                      width: 434*fem,
                      height: 868*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(20*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Align(
                        // perpus1veU (I34:592;19:78)
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          width: 414*fem,
                          height: 812*fem,
                          child: Image.asset(
                            'assets/page-1/images/perpus-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // r2L (34:593)
                    left: 0*fem,
                    top: 286*fem,
                    child: Container(
                      width: 1668*fem,
                      height: 582*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupft7vZhS (R1Y5FMSpNSH8Uh6tcffT7v)
                            margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 426*fem),
                            width: 1550*fem,
                            height: 28*fem,
                          ),
                          Container(
                            // containericonlefttDv (I34:616;34:581)
                            margin: EdgeInsets.fromLTRB(124*fem, 0*fem, 0*fem, 28*fem),
                            width: 179*fem,
                            height: 44*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(8*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x19000000),
                                  offset: Offset(0*fem, 1*fem),
                                  blurRadius: 4*fem,
                                ),
                                BoxShadow(
                                  color: Color(0x1e000000),
                                  offset: Offset(0*fem, 2*fem),
                                  blurRadius: 2*fem,
                                ),
                                BoxShadow(
                                  color: Color(0x28000000),
                                  offset: Offset(0*fem, 1*fem),
                                  blurRadius: 1*fem,
                                ),
                              ],
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // iconleftJ2k (I34:616;34:581;108:1389)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 80*fem,
                                      height: 44*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icon-left.png',
                                        width: 80*fem,
                                        height: 44*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // labelb1r (I34:616;34:581;108:1388)
                                  left: 65*fem,
                                  top: 8*fem,
                                  child: Center(
                                    child: Align(
                                      child: SizedBox(
                                        width: 49*fem,
                                        height: 28*fem,
                                        child: Text(
                                          'Back',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 20*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.4*ffem/fem,
                                            letterSpacing: 0.150000006*fem,
                                            color: Color(0xff263238),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouppqj4G7z (R1Y5Kw9Wyg7g7Q6LPbPQJ4)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: 56*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(8*fem),
                                topRight: Radius.circular(8*fem),
                              ),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemviL (I34:593;12:37;371:4252)
                                  padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icon3Y4 (I34:593;12:37;371:4252;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-8ac.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // label9b6 (I34:593;12:37;371:4252;371:4246)
                                        'Dashboard',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff858585),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // bnitemGfi (I34:593;12:38;371:4765)
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconzbi (I34:593;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-QBJ.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labeliXi (I34:593;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // bnitemdeg (I34:593;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // icon9N8 (I34:593;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-sVa.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelrnL (I34:593;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group6nvt (34:595)
                    left: 48*fem,
                    top: 150*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(10.71*fem, 22.56*fem, 11.29*fem, 18.38*fem),
                      width: 332*fem,
                      height: 531*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xaa565656),
                        borderRadius: BorderRadius.circular(20*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group54Nc (34:597)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25.63*fem),
                            width: double.infinity,
                            height: 47.16*fem,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffffffff)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'Login your account here',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 23*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2173913043*ffem/fem,
                                    letterSpacing: 0.150000006*fem,
                                    color: Color(0xb5000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // group7tMe (34:601)
                            padding: EdgeInsets.fromLTRB(14.29*fem, 26.53*fem, 11.71*fem, 24.61*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              border: Border.all(color: Color(0xffffffff)),
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // usercircleNnc (34:738)
                                  margin: EdgeInsets.fromLTRB(96*fem, 0*fem, 98*fem, 33.21*fem),
                                  padding: EdgeInsets.fromLTRB(10.18*fem, 14.88*fem, 10.18*fem, 0*fem),
                                  width: double.infinity,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/rectangle-1.png',
                                      ),
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // ellipse46rSt (I34:738;126:2896)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4.96*fem),
                                        width: 40*fem,
                                        height: 39.67*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ellipse-46.png',
                                          width: 40*fem,
                                          height: 39.67*fem,
                                        ),
                                      ),
                                      Container(
                                        // intersectmZr (I34:738;126:2897)
                                        width: 69.65*fem,
                                        height: 29.75*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/intersect.png',
                                          width: 69.65*fem,
                                          height: 29.75*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // labeluRA (34:607)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.21*fem),
                                  child: Text(
                                    'Email :',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // backgroundpHE (34:603)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25.28*fem),
                                  width: double.infinity,
                                  height: 32.56*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    border: Border.all(color: Color(0x30000000)),
                                    color: Color(0x42565656),
                                  ),
                                ),
                                Container(
                                  // labelYU8 (34:608)
                                  margin: EdgeInsets.fromLTRB(0.29*fem, 0*fem, 0*fem, 3.47*fem),
                                  child: Text(
                                    'Password :',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xb5000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // backgroundGQ8 (34:604)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16.78*fem),
                                  width: double.infinity,
                                  height: 32.56*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    border: Border.all(color: Color(0x30000000)),
                                    color: Color(0x42565656),
                                  ),
                                ),
                                Container(
                                  // autogroupbkekndN (R1Y64AS9rL2mviMFSTbkek)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 210.45*fem, 22.48*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // vectorimv (34:611)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
                                        width: 11*fem,
                                        height: 10.33*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-eZE.png',
                                          width: 11*fem,
                                          height: 10.33*fem,
                                        ),
                                      ),
                                      Container(
                                        // groupe9n (34:612)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.13*fem),
                                        width: 56.55*fem,
                                        height: 7.6*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/group-VJ8.png',
                                          width: 56.55*fem,
                                          height: 7.6*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // minibuttonxAU (34:614)
                                  margin: EdgeInsets.fromLTRB(101*fem, 0*fem, 102*fem, 0*fem),
                                  width: double.infinity,
                                  height: 41.01*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    borderRadius: BorderRadius.circular(5*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Login',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Kanit',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.495*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}