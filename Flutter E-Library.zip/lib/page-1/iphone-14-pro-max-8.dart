import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax8wmz (48:672)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // statusbardui (48:686)
              padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xfffcfcff),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timeYWt (I48:686;102:1072)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                    child: Text(
                      '9:30',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.14*fem,
                        color: Color(0xff1e1e1e),
                      ),
                    ),
                  ),
                  Container(
                    // righticons2BA (I48:686;102:1074)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                    width: 46*fem,
                    height: 17*fem,
                    child: Image.asset(
                      'assets/page-1/images/right-icons-fgt.png',
                      width: 46*fem,
                      height: 17*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // topdefaultukk (48:851)
              margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 9*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(8*fem),
                  bottomLeft: Radius.circular(8*fem),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x1e000000),
                    offset: Offset(0*fem, 1*fem),
                    blurRadius: 6*fem,
                  ),
                  BoxShadow(
                    color: Color(0x05000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 4*fem,
                  ),
                  BoxShadow(
                    color: Color(0x02000000),
                    offset: Offset(0*fem, 1*fem),
                    blurRadius: 2*fem,
                  ),
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // iconleftgf2 (I48:851;486:3092)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 223*fem, 0*fem),
                    width: 40*fem,
                    height: 40*fem,
                    child: Image.asset(
                      'assets/page-1/images/icon-left-qJ8.png',
                      width: 40*fem,
                      height: 40*fem,
                    ),
                  ),
                  Container(
                    // iconright11BW (I48:851;486:3093)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                    width: 40*fem,
                    height: 40*fem,
                    child: Image.asset(
                      'assets/page-1/images/icon-right-1-xFS.png',
                      width: 40*fem,
                      height: 40*fem,
                    ),
                  ),
                  Container(
                    // iconright27VS (I48:851;486:3094)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                    width: 40*fem,
                    height: 40*fem,
                    child: Image.asset(
                      'assets/page-1/images/icon-right-2-7RS.png',
                      width: 40*fem,
                      height: 40*fem,
                    ),
                  ),
                  Container(
                    // iconright3pek (I48:851;486:3095)
                    width: 40*fem,
                    height: 40*fem,
                    child: Image.asset(
                      'assets/page-1/images/icon-right-3-65v.png',
                      width: 40*fem,
                      height: 40*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupaencxFA (R1YcPdDnHmtwKkTCaKaeNC)
              width: 1668*fem,
              height: 823*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame7hCk (48:674)
                    left: 6*fem,
                    top: 0*fem,
                    child: Container(
                      width: 415*fem,
                      height: 767*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0x93ff3d00),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // backgroundPrG (48:675)
                            left: 11*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 394*fem,
                                height: 764.38*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(20*fem),
                                    border: Border.all(color: Color(0x93ff3d00)),
                                    color: Color(0xaa565656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // textpicrightwithbuttonVPW (48:888)
                            left: 33*fem,
                            top: 22*fem,
                            child: Container(
                              width: 352*fem,
                              height: 200*fem,
                              decoration: BoxDecoration (
                                border: Border.all(color: Color(0xffffffff)),
                                color: Color(0xff263238),
                                borderRadius: BorderRadius.circular(12*fem),
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    // autogroupsbgkMRi (R1YcnnDsBLviGXEuDasbgk)
                                    left: 231*fem,
                                    top: 16*fem,
                                    child: Container(
                                      width: 105*fem,
                                      height: 143*fem,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // image5Mi (48:910)
                                            left: 4*fem,
                                            top: 7*fem,
                                            child: Container(
                                              width: 96*fem,
                                              height: 136*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.cover,
                                                  image: AssetImage (
                                                    'assets/page-1/images/image-bg.png',
                                                  ),
                                                ),
                                              ),
                                              child: Center(
                                                // imgMq2 (I48:910;0:401)
                                                child: SizedBox(
                                                  width: double.infinity,
                                                  height: 136*fem,
                                                  child: Container(
                                                    decoration: BoxDecoration (
                                                      borderRadius: BorderRadius.circular(8*fem),
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // img61v (48:912)
                                            left: 0*fem,
                                            top: 4*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 96*fem,
                                                height: 136*fem,
                                                child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(10*fem),
                                                  child: Image.asset(
                                                    'assets/page-1/images/img-j8L.png',
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // autogroupdhbnCak (R1YcdCfVYaBD33Xt41dhbN)
                                    left: 8*fem,
                                    top: 17*fem,
                                    child: Container(
                                      width: 203*fem,
                                      height: 167*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // title7xc (I48:888;391:5161)
                                            margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 9*fem),
                                            child: Text(
                                              'Sistem Informasi',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 24*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.2125*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // bodyQRv (I48:888;391:5162)
                                            margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 68*fem),
                                            child: Text(
                                              'Analisa dan Perancangan',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.4285714286*ffem/fem,
                                                letterSpacing: 0.07*fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // labeledcentereduda (I48:888;391:5156;102:7178)
                                            width: 96*fem,
                                            height: 40*fem,
                                            decoration: BoxDecoration (
                                              border: Border.all(color: Color(0x89ffffff)),
                                              borderRadius: BorderRadius.circular(8*fem),
                                            ),
                                            child: Center(
                                              child: Center(
                                                child: Text(
                                                  'Reading',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.7142857143*ffem/fem,
                                                    letterSpacing: 0.1000000015*fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // icfavorite48pxApQ (48:914)
                                    left: 133*fem,
                                    top: 152*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icfavorite48px-fZJ.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // fFN (48:685)
                    left: 0*fem,
                    top: 241*fem,
                    child: Container(
                      width: 1668*fem,
                      height: 582*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // autogroupvxtvPx4 (R1YdES9nagQy1gPPZAvXTv)
                            margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                            width: 1550*fem,
                            height: 28*fem,
                          ),
                          Container(
                            // autogroup7fq2Kqi (R1YdKgW3TbAyPgwSiT7fq2)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                            width: double.infinity,
                            height: 56*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff0f0f0),
                              borderRadius: BorderRadius.only (
                                topLeft: Radius.circular(8*fem),
                                topRight: Radius.circular(8*fem),
                              ),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroup8qgpGPa (R1YdS6V2JvYY5Uj4oM8QGp)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(141*fem, 0*fem, 3*fem, 0*fem),
                                  width: 287*fem,
                                  height: double.infinity,
                                  child: Container(
                                    // destination1xXJ (48:806)
                                    padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                                    width: double.infinity,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                    ),
                                    child: Container(
                                      // bnitemtA4 (I48:806;371:4252)
                                      padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 31*fem, 4*fem),
                                      width: double.infinity,
                                      height: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroupqo44c64 (R1YdmavYiJWGv5vQpfqo44)
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-qo44.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                          Container(
                                            // autogroupzkecw8L (R1YdrAdFKYLpYnurbbZkEC)
                                            width: double.infinity,
                                            height: 16*fem,
                                            child: Center(
                                              child: Text(
                                                'Bookmarked',
                                                textAlign: TextAlign.center,
                                                style: SafeGoogleFont (
                                                  'Inter',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.3333333333*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // bnitemRZJ (I48:685;12:39;371:5376)
                                  margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 4*fem),
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconjK6 (I48:685;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-iXr.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelewr (I48:685;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // textpicrightwithbuttonBgt (48:920)
                    left: 39*fem,
                    top: 228*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(8*fem, 16*fem, 16*fem, 16*fem),
                      width: 352*fem,
                      height: 200*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xffffffff)),
                        color: Color(0xff263238),
                        borderRadius: BorderRadius.circular(12*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupukysRbE (R1YerJd3PqmJgxiayPUKyS)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 19*fem, 0*fem),
                            width: 204*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // titlejrp (I48:920;391:5161)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 9*fem),
                                  child: Text(
                                    'Sistem Informasi',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // bodyFaG (I48:920;391:5162)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 48*fem),
                                  constraints: BoxConstraints (
                                    maxWidth: 196*fem,
                                  ),
                                  child: Text(
                                    'Akutansi dengan Pendekatan Simulasi',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.07*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogrouplfnq99r (R1YewoTt88NMrD77uJLfnQ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55*fem, 0*fem),
                                  width: double.infinity,
                                  height: 40*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // labeledcentered5JQ (I48:920;391:5156;102:7178)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
                                        width: 96*fem,
                                        height: double.infinity,
                                        decoration: BoxDecoration (
                                          border: Border.all(color: Color(0x89ffffff)),
                                          borderRadius: BorderRadius.circular(8*fem),
                                        ),
                                        child: Center(
                                          child: Center(
                                            child: Text(
                                              'Reading',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.7142857143*ffem/fem,
                                                letterSpacing: 0.1000000015*fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // icfavorite48pxvZv (48:923)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icfavorite48px.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupdk3a3uS (R1Yf9iHhhkLyhFHGv7Dk3A)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
                            width: 105*fem,
                            height: 143*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // imageyo6 (48:921)
                                  left: 4*fem,
                                  top: 7*fem,
                                  child: Container(
                                    width: 96*fem,
                                    height: 136*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(10*fem),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/image-bg-wEp.png',
                                        ),
                                      ),
                                    ),
                                    child: Center(
                                      // imgghW (I48:921;0:401)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 136*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(8*fem),
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // imgDhS (48:922)
                                  left: 0*fem,
                                  top: 4*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 96*fem,
                                      height: 136*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(10*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/img-bEY.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}