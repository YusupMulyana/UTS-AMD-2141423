import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax12P9S (59:1326)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // frame86Ze (61:1175)
              left: 0*fem,
              top: 122*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(12*fem, 4*fem, 0*fem, 4*fem),
                width: 1095*fem,
                height: 200*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                ),
                child: Container(
                  // group21CMn (61:1165)
                  width: double.infinity,
                  height: 180*fem,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // bvYg (61:1123)
                        width: 168*fem,
                        height: double.infinity,
                        child: Container(
                          // gridcardtallV5z (61:1124)
                          width: double.infinity,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(4*fem),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x19000000),
                                offset: Offset(0*fem, 1*fem),
                                blurRadius: 4*fem,
                              ),
                              BoxShadow(
                                color: Color(0x1e000000),
                                offset: Offset(0*fem, 2*fem),
                                blurRadius: 2*fem,
                              ),
                              BoxShadow(
                                color: Color(0x28000000),
                                offset: Offset(0*fem, 1*fem),
                                blurRadius: 1*fem,
                              ),
                            ],
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                // imageYa4 (I61:1124;394:769)
                                left: 0*fem,
                                top: 0*fem,
                                child: Container(
                                  width: 168*fem,
                                  height: 108*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xffc4c4c4),
                                  ),
                                  child: Center(
                                    // img5pt (I61:1124;394:769;0:401)
                                    child: SizedBox(
                                      width: 168*fem,
                                      height: 108*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(4*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/img-eDe.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // overlaycK2 (I61:1124;394:779)
                                left: 0*fem,
                                top: 104*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 168*fem,
                                    height: 76*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.only (
                                          bottomRight: Radius.circular(4*fem),
                                          bottomLeft: Radius.circular(4*fem),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // titleh5a (I61:1124;394:771)
                                left: 16*fem,
                                top: 118*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 58*fem,
                                    height: 28*fem,
                                    child: Text(
                                      'Ology',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.4*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff263238),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // captionMvp (I61:1124;394:772)
                                left: 16*fem,
                                top: 146*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 44*fem,
                                    height: 20*fem,
                                    child: Text(
                                      'Galant',
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.4285714286*ffem/fem,
                                        letterSpacing: 0.07*fem,
                                        color: Color(0xff263238),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 15*fem,
                      ),
                      Container(
                        // gridcardtallqLC (I61:1132;61:1124)
                        width: 168*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x19000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x28000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 1*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // imageJDn (I61:1132;61:1124;394:769)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 168*fem,
                                height: 108*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffc4c4c4),
                                ),
                                child: Center(
                                  // imgEt8 (I61:1132;61:1124;394:769;0:401)
                                  child: SizedBox(
                                    width: 168*fem,
                                    height: 108*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(4*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/img-u1r.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // overlayZ9i (I61:1132;61:1124;394:779)
                              left: 0*fem,
                              top: 104*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 168*fem,
                                  height: 76*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.only (
                                        bottomRight: Radius.circular(4*fem),
                                        bottomLeft: Radius.circular(4*fem),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // titleruW (I61:1132;61:1124;394:771)
                              left: 16*fem,
                              top: 118*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 58*fem,
                                  height: 28*fem,
                                  child: Text(
                                    'Ology',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // captionkzt (I61:1132;61:1124;394:772)
                              left: 16*fem,
                              top: 146*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'Galant',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.07*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 15*fem,
                      ),
                      Container(
                        // gridcardtallT8c (I61:1140;61:1124)
                        width: 168*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x19000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x28000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 1*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // imageW6t (I61:1140;61:1124;394:769)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 168*fem,
                                height: 108*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffc4c4c4),
                                ),
                                child: Center(
                                  // imgqQ4 (I61:1140;61:1124;394:769;0:401)
                                  child: SizedBox(
                                    width: 168*fem,
                                    height: 108*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(4*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/img-ZEp.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // overlay9Qk (I61:1140;61:1124;394:779)
                              left: 0*fem,
                              top: 104*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 168*fem,
                                  height: 76*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.only (
                                        bottomRight: Radius.circular(4*fem),
                                        bottomLeft: Radius.circular(4*fem),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // titlepWt (I61:1140;61:1124;394:771)
                              left: 16*fem,
                              top: 118*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 58*fem,
                                  height: 28*fem,
                                  child: Text(
                                    'Ology',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // captionHvG (I61:1140;61:1124;394:772)
                              left: 16*fem,
                              top: 146*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'Galant',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.07*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 15*fem,
                      ),
                      Container(
                        // gridcardtallZct (I61:1148;61:1124)
                        width: 168*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x19000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x28000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 1*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // imageSRn (I61:1148;61:1124;394:769)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 168*fem,
                                height: 108*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffc4c4c4),
                                ),
                                child: Center(
                                  // imgnVe (I61:1148;61:1124;394:769;0:401)
                                  child: SizedBox(
                                    width: 168*fem,
                                    height: 108*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(4*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/img-SqW.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // overlayWAk (I61:1148;61:1124;394:779)
                              left: 0*fem,
                              top: 104*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 168*fem,
                                  height: 76*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.only (
                                        bottomRight: Radius.circular(4*fem),
                                        bottomLeft: Radius.circular(4*fem),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // titleQ1E (I61:1148;61:1124;394:771)
                              left: 16*fem,
                              top: 118*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 58*fem,
                                  height: 28*fem,
                                  child: Text(
                                    'Ology',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // captiontwz (I61:1148;61:1124;394:772)
                              left: 16*fem,
                              top: 146*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'Galant',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.07*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 15*fem,
                      ),
                      Container(
                        // gridcardtallNMN (I61:1156;61:1124)
                        width: 168*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x19000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x28000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 1*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // image3Cc (I61:1156;61:1124;394:769)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 168*fem,
                                height: 108*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffc4c4c4),
                                ),
                                child: Center(
                                  // imgyMA (I61:1156;61:1124;394:769;0:401)
                                  child: SizedBox(
                                    width: 168*fem,
                                    height: 108*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(4*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/img-wfe.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // overlaytDE (I61:1156;61:1124;394:779)
                              left: 0*fem,
                              top: 104*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 168*fem,
                                  height: 76*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.only (
                                        bottomRight: Radius.circular(4*fem),
                                        bottomLeft: Radius.circular(4*fem),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // titleark (I61:1156;61:1124;394:771)
                              left: 16*fem,
                              top: 118*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 58*fem,
                                  height: 28*fem,
                                  child: Text(
                                    'Ology',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // captionVip (I61:1156;61:1124;394:772)
                              left: 16*fem,
                              top: 146*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'Galant',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.07*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 15*fem,
                      ),
                      Container(
                        // gridcardtallb1A (I61:1166;61:1124)
                        width: 168*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(4*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x19000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 2*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x28000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 1*fem,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // imageTZA (I61:1166;61:1124;394:769)
                              left: 0*fem,
                              top: 0*fem,
                              child: Container(
                                width: 168*fem,
                                height: 108*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffc4c4c4),
                                ),
                                child: Center(
                                  // imgoN8 (I61:1166;61:1124;394:769;0:401)
                                  child: SizedBox(
                                    width: 168*fem,
                                    height: 108*fem,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(4*fem),
                                      child: Image.asset(
                                        'assets/page-1/images/img-Mbn.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // overlayjWg (I61:1166;61:1124;394:779)
                              left: 0*fem,
                              top: 104*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 168*fem,
                                  height: 76*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.only (
                                        bottomRight: Radius.circular(4*fem),
                                        bottomLeft: Radius.circular(4*fem),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // titlee7r (I61:1166;61:1124;394:771)
                              left: 16*fem,
                              top: 118*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 58*fem,
                                  height: 28*fem,
                                  child: Text(
                                    'Ology',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 20*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.4*ffem/fem,
                                      letterSpacing: 0.150000006*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // captionYDE (I61:1166;61:1124;394:772)
                              left: 16*fem,
                              top: 146*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 44*fem,
                                  height: 20*fem,
                                  child: Text(
                                    'Galant',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.07*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // group23qTE (71:1154)
              left: 8*fem,
              top: 318*fem,
              child: Container(
                width: 414*fem,
                height: 701*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // group11MgU (61:1092)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(10*fem, 13.54*fem, 10*fem, 0*fem),
                        width: 414*fem,
                        height: 614*fem,
                        decoration: BoxDecoration (
                          image: DecorationImage (
                            fit: BoxFit.cover,
                            image: AssetImage (
                              'assets/page-1/images/frame-7.png',
                            ),
                          ),
                        ),
                        child: Align(
                          // backgroundEVN (61:1091)
                          alignment: Alignment.bottomCenter,
                          child: SizedBox(
                            width: double.infinity,
                            height: 600.46*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                border: Border.all(color: Color(0x93ff3d00)),
                                color: Color(0xaa565656),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group22mEQ (69:1153)
                      left: 9*fem,
                      top: 18*fem,
                      child: Container(
                        width: 158*fem,
                        height: 683*fem,
                        child: Stack(
                          children: [
                            Positioned(
                              // background5F6 (61:1094)
                              left: 1*fem,
                              top: 0*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 156*fem,
                                  height: 683*fem,
                                  child: Container(
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xffffffff)),
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // labelzcx (69:1137)
                              left: 27.5*fem,
                              top: 2.5*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 102*fem,
                                    height: 28*fem,
                                    child: Text(
                                      'Kategori',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 24*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.1666666667*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // label5eQ (69:1140)
                              left: 30.5*fem,
                              top: 67*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 96*fem,
                                    height: 56*fem,
                                    child: Text(
                                      'Buku SIstem Informasi',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.75*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // labelAfr (69:1147)
                              left: 30.5*fem,
                              top: 279*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 96*fem,
                                    height: 84*fem,
                                    child: Text(
                                      'Buku Desain Komunikasi\nVisual',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.75*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // labelFxC (69:1150)
                              left: 40.5*fem,
                              top: 399.5*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 78*fem,
                                    height: 84*fem,
                                    child: Text(
                                      'Buku Fiksi\nDan\nnon Fiksi',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.75*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // labeljcU (69:1142)
                              left: 32*fem,
                              top: 174*fem,
                              child: Center(
                                child: Align(
                                  child: SizedBox(
                                    width: 93*fem,
                                    height: 56*fem,
                                    child: Text(
                                      'Buku Teknik Informatika',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.75*ffem/fem,
                                        letterSpacing: 0.150000006*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // dividercgG (69:1138)
                              left: 0*fem,
                              top: 38*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 157*fem,
                                  height: 1*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/divider-9rx.png',
                                    width: 157*fem,
                                    height: 1*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // dividerWme (69:1143)
                              left: 1*fem,
                              top: 156*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 157*fem,
                                  height: 1*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/divider-Rya.png',
                                    width: 157*fem,
                                    height: 1*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // dividernjA (69:1145)
                              left: 0*fem,
                              top: 250*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 157*fem,
                                  height: 1*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/divider-Wmv.png',
                                    width: 157*fem,
                                    height: 1*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // dividergJk (69:1148)
                              left: 0*fem,
                              top: 394*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 157*fem,
                                  height: 1*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/divider-m5i.png',
                                    width: 157*fem,
                                    height: 1*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // dividerCXz (69:1151)
                              left: 0*fem,
                              top: 491*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 157*fem,
                                  height: 1*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/divider-1qi.png',
                                    width: 157*fem,
                                    height: 1*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // statusbarXqA (59:1330)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeEUg (I59:1330;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsLnc (I59:1330;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-cgx.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group20f4C (59:1478)
              left: 7*fem,
              top: 52*fem,
              child: Container(
                width: 415*fem,
                height: 56*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // topdefaultbCk (59:1479)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(271*fem, 8*fem, 8*fem, 8*fem),
                        width: 415*fem,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.only (
                            bottomRight: Radius.circular(8*fem),
                            bottomLeft: Radius.circular(8*fem),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x1e000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 6*fem,
                            ),
                            BoxShadow(
                              color: Color(0x05000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 4*fem,
                            ),
                            BoxShadow(
                              color: Color(0x02000000),
                              offset: Offset(0*fem, 1*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // iconright1zkg (I59:1479;486:3093)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-1-CTi.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright274c (I59:1479;486:3094)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-2-RZa.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                            SizedBox(
                              width: 8*fem,
                            ),
                            Container(
                              // iconright32Ba (I59:1479;486:3095)
                              width: 40*fem,
                              height: 40*fem,
                              child: Image.asset(
                                'assets/page-1/images/icon-right-3-Xyi.png',
                                width: 40*fem,
                                height: 40*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // iconleftYQp (59:1480)
                      left: 4*fem,
                      top: 8*fem,
                      child: Align(
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-left-z6t.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // labelqui (69:1136)
              left: 48*fem,
              top: 65.5*fem,
              child: Center(
                child: Align(
                  child: SizedBox(
                    width: 81*fem,
                    height: 28*fem,
                    child: Text(
                      'Kategori',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.4*ffem/fem,
                        letterSpacing: 0.150000006*fem,
                        color: Color(0xff263238),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // uua (59:1329)
              left: 0*fem,
              top: 876*fem,
              child: Container(
                width: 430*fem,
                height: 56*fem,
                child: Container(
                  // autogroupeckq41n (R1YVx4TEZgeHG7sR8yEckQ)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    color: Color(0xfff0f0f0),
                    borderRadius: BorderRadius.only (
                      topLeft: Radius.circular(8*fem),
                      topRight: Radius.circular(8*fem),
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // destination1NYG (I59:1329;12:37)
                        padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                        width: 143*fem,
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                        ),
                        child: Container(
                          // bnitembA8 (I59:1329;12:37;371:4252)
                          padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                          width: double.infinity,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // iconKM2 (I59:1329;12:37;371:4252;371:4235)
                                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-hEG.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                              Text(
                                // labeldcc (I59:1329;12:37;371:4252;371:4246)
                                'Dashboard',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        // autogroupgx3aAcY (R1YW4Pc28ZQAMViDJKgx3a)
                        padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                        height: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // bnitem6WC (I59:1329;12:38;371:4765)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                              padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                              width: 136*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconofW (I59:1329;12:38;371:4765;371:4235)
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-kbr.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelKdr (I59:1329;12:38;371:4765;371:4246)
                                    'Bookmarked',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // bnitemTk4 (I59:1329;12:39;371:5376)
                              padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                              width: 135*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconaZn (I59:1329;12:39;371:5376;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-Kk4.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelVgk (I59:1329;12:39;371:5376;371:4246)
                                    'Wishlist',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}