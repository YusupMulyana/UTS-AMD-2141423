import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax17Xdr (71:2144)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              // topdefaultE2U (71:2145)
              left: 6*fem,
              top: 53*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                width: 415*fem,
                height: 56*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.only (
                    bottomRight: Radius.circular(8*fem),
                    bottomLeft: Radius.circular(8*fem),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 6*fem,
                    ),
                    BoxShadow(
                      color: Color(0x05000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 4*fem,
                    ),
                    BoxShadow(
                      color: Color(0x02000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // iconleftzQx (I71:2145;486:3092)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 223*fem, 0*fem),
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-left-XyJ.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // iconright1hKN (I71:2145;486:3093)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-right-1-8gQ.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // iconright2CG8 (I71:2145;486:3094)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-right-2-vCp.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                    Container(
                      // iconright378C (I71:2145;486:3095)
                      width: 40*fem,
                      height: 40*fem,
                      child: Image.asset(
                        'assets/page-1/images/icon-right-3-Nwz.png',
                        width: 40*fem,
                        height: 40*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupd2acSAU (R1YF2VKVayJFRnWuWYD2AC)
              left: 7*fem,
              top: 115*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(18*fem, 37*fem, 19*fem, 37*fem),
                width: 415*fem,
                height: 769*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(8*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x19000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 4*fem,
                    ),
                    BoxShadow(
                      color: Color(0x1e000000),
                      offset: Offset(0*fem, 2*fem),
                      blurRadius: 2*fem,
                    ),
                    BoxShadow(
                      color: Color(0x28000000),
                      offset: Offset(0*fem, 1*fem),
                      blurRadius: 1*fem,
                    ),
                  ],
                ),
                child: Container(
                  // group26qTW (75:1529)
                  width: double.infinity,
                  height: 115*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // Akg (75:1536)
                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 27*fem),
                        width: 377*fem,
                        height: 44*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfff0f0f0),
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Container(
                          // defaultsingleiconizedgj2 (I75:1536;71:1528)
                          width: double.infinity,
                          height: double.infinity,
                          child: Container(
                            // autogrouphbpeSCQ (R1YG3TdEVrsZW5mu7mhbPe)
                            padding: EdgeInsets.fromLTRB(16*fem, 2*fem, 10*fem, 1*fem),
                            width: double.infinity,
                            height: 43*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroup17769sW (R1YGBhtVbHn9ExMhWe1776)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  width: 40*fem,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // iconleftfax (I75:1536;71:1531)
                                        left: 8*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/icon-left-DRS.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // imgmP6 (I75:1536;71:1536)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 40*fem,
                                            height: 40*fem,
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(2*fem),
                                              child: Image.asset(
                                                'assets/page-1/images/img.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // label5eg (I75:1536;71:1537)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 172*fem, 0*fem),
                                  child: Text(
                                    'Pencarian',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      letterSpacing: 0.16*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupk3msARE (R1YGH7u937mWonoQX1K3mS)
                                  margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(17*fem, 0*fem, 0*fem, 0*fem),
                                  height: double.infinity,
                                  child: Align(
                                    // iconrightHEx (75:1537)
                                    alignment: Alignment.centerRight,
                                    child: SizedBox(
                                      width: 29*fem,
                                      height: 24*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icon-right-zVn.png',
                                        width: 29*fem,
                                        height: 24*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // Csi (75:1534)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                        width: 377*fem,
                        height: 44*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfff0f0f0),
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Container(
                          // defaultsingleiconizedj6x (I75:1534;71:1528)
                          width: double.infinity,
                          height: double.infinity,
                          child: Container(
                            // autogroupctmjGsa (R1YFHQ4KP7RSdgiokwCTmJ)
                            padding: EdgeInsets.fromLTRB(16*fem, 2*fem, 16*fem, 1*fem),
                            width: double.infinity,
                            height: 43*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroup4ndnPxC (R1YFRj9mkzwhxyFS5M4NdN)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  height: double.infinity,
                                  child: Center(
                                    // imgjWG (I75:1534;71:1536)
                                    child: SizedBox(
                                      width: 40*fem,
                                      height: 40*fem,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(2*fem),
                                        child: Image.asset(
                                          'assets/page-1/images/img-9eQ.png',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // labelTx4 (I75:1534;71:1537)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 176*fem, 0*fem),
                                  child: Text(
                                    'Notifikasi',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      letterSpacing: 0.16*fem,
                                      color: Color(0xff263238),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupf6znNJL (R1YFYyShSvU6atVKPgf6ZN)
                                  margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 8*fem),
                                  padding: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 2*fem),
                                  height: double.infinity,
                                  child: Center(
                                    // switchtXa (I75:1534;71:1543)
                                    child: SizedBox(
                                      width: 40*fem,
                                      height: 20*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/switch-s6g.png',
                                        width: 40*fem,
                                        height: 20*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // statusbarQkp (71:2146)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(24*fem, 23*fem, 24*fem, 10*fem),
                width: 432*fem,
                height: 53*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffcfcff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timesPW (I71:2146;102:1072)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 309*fem, 0*fem),
                      child: Text(
                        '9:30',
                        style: SafeGoogleFont (
                          'Roboto',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.4285714286*ffem/fem,
                          letterSpacing: 0.14*fem,
                          color: Color(0xff1e1e1e),
                        ),
                      ),
                    ),
                    Container(
                      // righticonsaHv (I71:2146;102:1074)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      width: 46*fem,
                      height: 17*fem,
                      child: Image.asset(
                        'assets/page-1/images/right-icons-Qr4.png',
                        width: 46*fem,
                        height: 17*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // 61N (71:2171)
              left: 0*fem,
              top: 350*fem,
              child: Container(
                width: 1668*fem,
                height: 582*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroupybyjpi4 (R1YHKkpmdBeUkLxvb7ybyJ)
                      margin: EdgeInsets.fromLTRB(118*fem, 0*fem, 0*fem, 498*fem),
                      width: 1550*fem,
                      height: 28*fem,
                    ),
                    Container(
                      // autogroupqlvtAG8 (R1YHRLVodvsDW1JHSaQLvt)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1238*fem, 0*fem),
                      width: double.infinity,
                      height: 56*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfff0f0f0),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(8*fem),
                          topRight: Radius.circular(8*fem),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // destination19Nx (I71:2171;12:37)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            width: 143*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff1f1f1),
                            ),
                            child: Container(
                              // bnitemsZr (I71:2171;12:37;371:4252)
                              padding: EdgeInsets.fromLTRB(36*fem, 4*fem, 36*fem, 4*fem),
                              width: double.infinity,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconQJt (I71:2171;12:37;371:4252;371:4235)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon-rKz.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labelv2L (I71:2171;12:37;371:4252;371:4246)
                                    'Dashboard',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      color: Color(0xff858585),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            // autogroupcxbaF4c (R1YHjQp2DWNMFbRamecxBa)
                            padding: EdgeInsets.fromLTRB(4*fem, 4*fem, 4*fem, 4*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bnitemBDA (I71:2171;12:38;371:4765)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                  padding: EdgeInsets.fromLTRB(32*fem, 4*fem, 32*fem, 4*fem),
                                  width: 136*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconHGC (I71:2171;12:38;371:4765;371:4235)
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-XKe.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelQrc (I71:2171;12:38;371:4765;371:4246)
                                        'Bookmarked',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // bnitemZDi (I71:2171;12:39;371:5376)
                                  padding: EdgeInsets.fromLTRB(44.5*fem, 4*fem, 44.5*fem, 4*fem),
                                  width: 135*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // iconUba (I71:2171;12:39;371:5376;371:4235)
                                        margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                        width: 24*fem,
                                        height: 24*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/icon-1VA.png',
                                          width: 24*fem,
                                          height: 24*fem,
                                        ),
                                      ),
                                      Text(
                                        // labelnsA (I71:2171;12:39;371:5376;371:4246)
                                        'Wishlist',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.3333333333*ffem/fem,
                                          color: Color(0xff263238),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}